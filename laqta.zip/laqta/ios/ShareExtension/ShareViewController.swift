import SwiftUI
import UIKit
import UniformTypeIdentifiers

/// Appears in the share sheet of TikTok / Instagram / X as “حفظ بلقطة”.
/// Takes the shared link and saves the media straight into Photos (HQ by default).
final class ShareViewController: UIViewController {
    private let client = LaqtaClient()

    override func viewDidLoad() {
        super.viewDidLoad()
        let host = UIHostingController(rootView: ShareStatusView(client: client) { [weak self] in
            self?.extensionContext?.completeRequest(returningItems: nil)
        })
        addChild(host)
        host.view.frame = view.bounds
        host.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(host.view)
        host.didMove(toParent: self)
        Task { await handleInput() }
    }

    private func handleInput() async {
        let providers = (extensionContext?.inputItems as? [NSExtensionItem])?.flatMap { $0.attachments ?? [] } ?? []
        var text: String?
        for p in providers {
            if p.hasItemConformingToTypeIdentifier(UTType.url.identifier),
               let url = try? await p.loadItem(forTypeIdentifier: UTType.url.identifier) as? URL {
                text = url.absoluteString; break
            }
            if p.hasItemConformingToTypeIdentifier(UTType.plainText.identifier),
               let s = try? await p.loadItem(forTypeIdentifier: UTType.plainText.identifier) as? String {
                text = s; break
            }
        }
        await client.run(link: text ?? "", quality: .hq)
    }
}

private struct ShareStatusView: View {
    @ObservedObject var client: LaqtaClient
    let close: () -> Void

    var body: some View {
        VStack(spacing: 16) {
            switch client.phase {
            case let .downloading(i, n, f, _, _):
                ProgressView(value: f) { Text("\(i + 1)/\(n)") }
            case let .done(n):
                Label(L10n.t("تم حفظ \(n) في الصور", "Saved \(n) to Photos"), systemImage: "checkmark.circle.fill")
                    .foregroundStyle(.green)
                    .task { try? await Task.sleep(nanoseconds: 900_000_000); close() }
            case let .failed(code):
                Text(L10n.error(code)).multilineTextAlignment(.center)
                Button(L10n.t("إغلاق", "Close"), action: close)
            default:
                ProgressView(L10n.t("نجهّز…", "Preparing…"))
            }
        }
        .padding(28)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(red: 0.08, green: 0.07, blue: 0.11))
        .preferredColorScheme(.dark)
    }
}
