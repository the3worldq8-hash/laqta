import SwiftUI

@main
struct LaqtaApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}

struct ContentView: View {
    @StateObject private var client = LaqtaClient()
    @State private var link = ""
    @State private var quality: LaqtaClient.Quality = .hq

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text(L10n.t("احفظ اللقطة كما نُشرت", "Keep the moment, exactly as posted"))
                .font(.system(size: 34, weight: .semibold))
            HStack {
                TextField(L10n.t("الصق الرابط هنا", "Paste a link"), text: $link)
                    .textInputAutocapitalization(.never).keyboardType(.URL).autocorrectionDisabled()
                PasteButton(payloadType: String.self) { strings in
                    if let s = strings.first { link = s; start() }
                }
                .labelStyle(.titleAndIcon)
            }
            .padding(12).background(.thinMaterial, in: RoundedRectangle(cornerRadius: 18))

            Picker("", selection: $quality) {
                Text(L10n.t("عادية", "Standard")).tag(LaqtaClient.Quality.standard)
                Text(L10n.t("عالية", "High")).tag(LaqtaClient.Quality.hq)
            }.pickerStyle(.segmented)

            Button(action: start) {
                Text(L10n.t("حفظ في الصور", "Save to Photos")).frame(maxWidth: .infinity).padding(.vertical, 14)
            }
            .buttonStyle(.borderedProminent).disabled(busy)

            status
            Spacer()
        }
        .padding(24)
        .preferredColorScheme(.dark)
        .onOpenURL { url in   // laqta://save?url=...
            if let q = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems?.first(where: { $0.name == "url" })?.value {
                link = q; start()
            }
        }
    }

    private var busy: Bool {
        switch client.phase { case .resolving, .downloading, .saving: return true; default: return false }
    }

    private func start() { Task { await client.run(link: link, quality: quality) } }

    @ViewBuilder private var status: some View {
        switch client.phase {
        case .idle: EmptyView()
        case .resolving: ProgressView(L10n.t("نقرأ المنشور…", "Reading the post…"))
        case let .downloading(i, n, f, bytes, total):
            VStack(alignment: .leading) {
                ProgressView(value: f)
                Text("\(i + 1)/\(n)  " + ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file)
                     + (total > 0 ? " / " + ByteCountFormatter.string(fromByteCount: total, countStyle: .file) : ""))
                    .font(.footnote).monospacedDigit().foregroundStyle(.secondary)
            }
        case .saving: ProgressView(L10n.t("نحفظ في الصور…", "Saving to Photos…"))
        case let .done(n): Label(L10n.t("تم حفظ \(n) في الصور", "Saved \(n) to Photos"), systemImage: "checkmark.circle.fill").foregroundStyle(.green)
        case let .failed(code): Text(L10n.error(code)).foregroundStyle(.red)
        }
    }
}
