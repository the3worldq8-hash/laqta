import Foundation
import Photos
import UniformTypeIdentifiers

/// Talks to the Laqta backend (`/api/shortcut` + `/api/fetch/...`) and saves results into Photos.
/// Photos access is requested as **add-only** (`.addOnly`): the app can add, never read, the library.
@MainActor
final class LaqtaClient: NSObject, ObservableObject {
    enum Quality: String, CaseIterable, Identifiable { case standard, hq; var id: String { rawValue } }

    enum Phase: Equatable {
        case idle, resolving
        case downloading(index: Int, count: Int, fraction: Double, bytes: Int64, total: Int64)
        case saving, done(count: Int), failed(String)
    }

    struct ShortcutFile: Decodable { let url: URL; let type: String; let quality: String }
    struct ShortcutResponse: Decodable { let platform: String; let count: Int; let files: [ShortcutFile] }
    struct APIError: Decodable { let code: String }

    @Published var phase: Phase = .idle
    let server: URL

    override init() {
        let raw = Bundle.main.object(forInfoDictionaryKey: "LaqtaServer") as? String ?? "https://laqta.example.com"
        server = URL(string: raw)!
        super.init()
    }

    static func firstURL(in text: String) -> URL? {
        let detector = try? NSDataDetector(types: NSTextCheckingResult.CheckingType.link.rawValue)
        let range = NSRange(text.startIndex..., in: text)
        return detector?.firstMatch(in: text, range: range)?.url
    }

    func run(link: String, quality: Quality) async {
        guard let postURL = Self.firstURL(in: link) else { phase = .failed("err_invalid_url"); return }
        do {
            guard await requestAddAccess() else { phase = .failed("photos_denied"); return }
            phase = .resolving
            var comps = URLComponents(url: server.appendingPathComponent("api/shortcut"), resolvingAgainstBaseURL: false)!
            comps.queryItems = [.init(name: "url", value: postURL.absoluteString), .init(name: "q", value: quality.rawValue)]
            let (data, resp) = try await URLSession.shared.data(from: comps.url!)
            try Self.check(resp, data)
            let info = try JSONDecoder().decode(ShortcutResponse.self, from: data)

            var saved = 0
            for (i, file) in info.files.enumerated() {
                let local = try await download(file.url, index: i, count: info.count)
                phase = .saving
                try await saveToPhotos(local, isVideo: file.type == "video")
                try? FileManager.default.removeItem(at: local)
                saved += 1
            }
            phase = .done(count: saved)
        } catch let e as LocalizedCodeError {
            phase = .failed(e.code)
        } catch {
            phase = .failed("err_network")
        }
    }

    // MARK: networking
    struct LocalizedCodeError: Error { let code: String }

    static func check(_ resp: URLResponse, _ data: Data?) throws {
        guard let http = resp as? HTTPURLResponse else { throw LocalizedCodeError(code: "err_network") }
        guard (200..<300).contains(http.statusCode) else {
            let code = data.flatMap { try? JSONDecoder().decode(APIError.self, from: $0).code } ?? "upstream"
            throw LocalizedCodeError(code: "err_\(code)")
        }
    }

    private func download(_ url: URL, index: Int, count: Int) async throws -> URL {
        phase = .downloading(index: index, count: count, fraction: 0, bytes: 0, total: 0)
        let delegate = ProgressDelegate { [weak self] written, total in
            Task { @MainActor in
                self?.phase = .downloading(index: index, count: count,
                                           fraction: total > 0 ? Double(written) / Double(total) : 0,
                                           bytes: written, total: total)
            }
        }
        let (tmp, resp) = try await URLSession.shared.download(from: url, delegate: delegate)
        try Self.check(resp, nil)
        // keep the server's filename/extension so Photos detects the type correctly
        let name = (resp as? HTTPURLResponse)?.value(forHTTPHeaderField: "X-Laqta-Filename")
            ?? resp.suggestedFilename ?? "laqta_\(index).\(url.pathExtension.isEmpty ? "mp4" : url.pathExtension)"
        let dest = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + "_" + name)
        try FileManager.default.moveItem(at: tmp, to: dest)
        return dest
    }

    // MARK: Photos
    private func requestAddAccess() async -> Bool {
        let status = PHPhotoLibrary.authorizationStatus(for: .addOnly)
        if status == .authorized || status == .limited { return true }
        if status == .notDetermined {
            let s = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
            return s == .authorized || s == .limited
        }
        return false
    }

    private func saveToPhotos(_ file: URL, isVideo: Bool) async throws {
        try await PHPhotoLibrary.shared().performChanges {
            let req = PHAssetCreationRequest.forAsset()
            let opts = PHAssetResourceCreationOptions()
            opts.originalFilename = file.lastPathComponent
            req.addResource(with: isVideo ? .video : .photo, fileURL: file, options: opts)
        }
    }
}

final class ProgressDelegate: NSObject, URLSessionDownloadDelegate, URLSessionTaskDelegate {
    let onProgress: (Int64, Int64) -> Void
    init(onProgress: @escaping (Int64, Int64) -> Void) { self.onProgress = onProgress }
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64,
                    totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        onProgress(totalBytesWritten, totalBytesExpectedToWrite)
    }
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {}
}

enum L10n {
    static var isArabic: Bool { Locale.preferredLanguages.first?.hasPrefix("ar") ?? false }
    static func t(_ ar: String, _ en: String) -> String { isArabic ? ar : en }
    static func error(_ code: String) -> String {
        switch code {
        case "err_invalid_url": return t("الرابط غير صالح.", "That isn't a valid link.")
        case "err_unsupported": return t("الرابط ليس من TikTok أو Instagram أو X.", "Link isn't from TikTok, Instagram or X.")
        case "err_not_found": return t("لم نجد المنشور.", "Post not found.")
        case "err_private": return t("المنشور خاص أو يحتاج تسجيل دخول.", "The post is private or needs a login.")
        case "err_rate_limited": return t("طلبات كثيرة، انتظر قليلًا.", "Too many requests, wait a moment.")
        case "photos_denied": return t("اسمح بإضافة الصور من الإعدادات ← لقطة ← الصور.", "Allow adding photos in Settings › Laqta › Photos.")
        default: return t("تعذّر الحفظ. حاول مرة أخرى.", "Couldn't save. Please try again.")
        }
    }
}
