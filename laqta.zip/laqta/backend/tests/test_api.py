"""End-to-end: resolve -> plan -> job -> deliver -> verify the actual files with ffprobe/Pillow."""
from __future__ import annotations

import io
import time

from PIL import Image

from app.config import settings
from app.media import probe


def resolve(c, url):
    r = c.post("/api/resolve", json={"url": url})
    assert r.status_code == 200, r.text
    return r.json()


def download(c, option):
    job = c.post("/api/jobs", json={"token": option["token"]}).json()
    for _ in range(600):
        if job["state"] in ("ready", "error"):
            break
        time.sleep(0.1)
        job = c.get(f"/api/jobs/{job['id']}").json()
    assert job["state"] == "ready", job
    r = c.get(f"/api/jobs/{job['id']}/file")
    assert r.status_code == 200, r.text
    assert "attachment" in r.headers["content-disposition"]
    if "content-length" in r.headers:
        assert int(r.headers["content-length"]) == len(r.content)
    return job, r


def save_and_probe(tmp_path, name, content):
    p = tmp_path / name
    p.write_bytes(content)
    info = probe(p)
    v = next(s for s in info["streams"] if s["codec_type"] == "video")
    return info, v


def test_multi_rendition_video(app_client, tmp_path):
    d = resolve(app_client, "https://fake.test/multi")
    opts = d["items"][0]["options"]
    std, hq = opts["standard"], opts["hq"]
    assert hq["resolution"] == "1080p" and std["resolution"] == "720p"
    # exact sizes discovered before download
    assert hq["size_exact"] and std["size_exact"] and std["size"] < hq["size"]
    _, r_hq = download(app_client, hq)
    _, r_sd = download(app_client, std)
    assert len(r_hq.content) == hq["size"] and len(r_sd.content) == std["size"]
    _, v = save_and_probe(tmp_path, "hq.mp4", r_hq.content)
    assert (v["width"], v["height"]) == (1080, 1920)


def test_single_rendition_gets_real_transcode(app_client, tmp_path):
    d = resolve(app_client, "https://fake.test/single1080")
    std, hq = d["items"][0]["options"]["standard"], d["items"][0]["options"]["hq"]
    assert std["method"] == "transcode" and "transcoded" in std["notes"]
    assert std["resolution"] == "720p" and not std["size_exact"]
    _, r_sd = download(app_client, std)
    _, r_hq = download(app_client, hq)
    info, v = save_and_probe(tmp_path, "sd.mp4", r_sd.content)
    assert min(v["width"], v["height"]) == 720
    assert v["codec_name"] == "h264"
    assert any(s["codec_type"] == "audio" for s in info["streams"])
    assert len(r_sd.content) < 0.5 * len(r_hq.content)
    # bitrate honours the cap (1800k video + 96k audio, small tolerance for container)
    assert int(info["format"]["bit_rate"]) < 2_100_000
    # estimate shown before download was in the right ballpark (upper bound)
    assert len(r_sd.content) <= std["size"] * 1.15


def test_low_single_rendition_is_honest(app_client):
    d = resolve(app_client, "https://fake.test/single720")
    opts = d["items"][0]["options"]
    assert opts["standard"] is None
    assert "single_quality" in opts["hq"]["notes"]
    assert opts["hq"]["resolution"] == "720p"


def test_carousel_images_and_video(app_client):
    d = resolve(app_client, "https://fake.test/carousel")
    assert [i["type"] for i in d["items"]] == ["image", "image", "video"]
    big = d["items"][0]["options"]
    assert big["standard"]["method"] == "resize" and big["standard"]["width"] == 1600
    _, r_hq = download(app_client, big["hq"])
    _, r_sd = download(app_client, big["standard"])
    assert Image.open(io.BytesIO(r_hq.content)).size == (4000, 3000)
    assert Image.open(io.BytesIO(r_sd.content)).size == (1600, 1200)
    assert len(r_sd.content) < len(r_hq.content)
    # webp is converted to JPEG for Photos compatibility, not upscaled
    webp = d["items"][1]["options"]
    assert webp["standard"] is None and webp["hq"]["method"] == "convert"
    job, r = download(app_client, webp["hq"])
    im = Image.open(io.BytesIO(r.content))
    assert im.format == "JPEG" and im.size == (1080, 1440)
    assert job["filename"].endswith("_2_HQ.jpg")


def test_ytdlp_formats_hevc_retag_and_no_watermark(app_client, tmp_path):
    d = resolve(app_client, "https://fake.test/ytdlp")
    std, hq = d["items"][0]["options"]["standard"], d["items"][0]["options"]["hq"]
    assert hq["resolution"] == "1080p" and hq["method"] == "remux"
    assert std["resolution"] == "720p" and std["method"] == "stream"
    _, r_hq = download(app_client, hq)
    info, v = save_and_probe(tmp_path, "hevc.mp4", r_hq.content)
    assert v["codec_name"] == "hevc" and v["codec_tag_string"] == "hvc1"  # iPhone Photos-compatible
    _, r_sd = download(app_client, std)
    assert len(r_sd.content) == std["size"]


def test_dash_merge(app_client, tmp_path):
    d = resolve(app_client, "https://fake.test/dash")
    hq = d["items"][0]["options"]["hq"]
    assert hq["method"] == "merge"
    _, r = download(app_client, hq)
    info, v = save_and_probe(tmp_path, "merged.mp4", r.content)
    assert {s["codec_type"] for s in info["streams"]} == {"video", "audio"}
    assert (v["width"], v["height"]) == (1080, 1920)


def test_no_files_left_behind(app_client):
    import shutil
    shutil.rmtree(settings.tmp_dir, ignore_errors=True)
    settings.tmp_dir.mkdir(parents=True, exist_ok=True)
    d = resolve(app_client, "https://fake.test/single1080")
    download(app_client, d["items"][0]["options"]["standard"])
    time.sleep(0.3)
    leftovers = [p for p in settings.tmp_dir.rglob("*") if p.is_file()]
    assert leftovers == []


def test_errors_and_tokens(app_client):
    assert app_client.post("/api/resolve", json={"url": "hello"}).json()["code"] == "invalid_url"
    assert app_client.post("/api/resolve", json={"url": "https://youtube.com/watch?v=1"}).json()["code"] == "unsupported"
    r = app_client.post("/api/resolve", json={"url": "https://fake.test/gone"})
    assert r.status_code == 404 and r.json()["code"] == "not_found"
    r = app_client.post("/api/jobs", json={"token": "forged.token"})
    assert r.status_code == 400 and r.json()["code"] == "expired"


def test_thumbnail_proxy_and_headers(app_client):
    d = resolve(app_client, "https://fake.test/multi")
    r = app_client.get(d["items"][0]["thumb"])
    assert r.status_code == 200 and r.headers["content-type"].startswith("image/")
    page = app_client.get("/")
    assert page.status_code == 200 and "default-src 'self'" in page.headers["content-security-policy"]


def test_shortcut_endpoint(app_client):
    r = app_client.get("/api/shortcut", params={"url": "https://fake.test/carousel", "q": "standard"})
    data = r.json()
    assert data["count"] == 3
    # item without a Standard rendition falls back to HQ instead of failing
    assert [f["quality"] for f in data["files"]] == ["standard", "hq", "hq"]
    f = app_client.get(data["urls"][0].replace("http://testserver", ""))
    assert f.status_code == 200 and Image.open(io.BytesIO(f.content)).size == (1600, 1200)
