"""Run the real app against local fixture media (no platform access needed).

    python -m tests.demo_server   ->  http://127.0.0.1:8765  (try https://fake.test/carousel)
"""
import pytest  # noqa: F401  (fixtures reuse)
import uvicorn

from tests import conftest


class _TPF:
    def mktemp(self, *_):
        import tempfile, pathlib
        return pathlib.Path(tempfile.mkdtemp())


if __name__ == "__main__":
    cdn_gen = conftest.cdn.__wrapped__()
    cdn = next(cdn_gen)
    gen = conftest.app_client.__wrapped__(cdn, _TPF())
    next(gen)  # registers fake provider + patches host guard
    from app.main import app
    uvicorn.run(app, host="127.0.0.1", port=8765, log_level="warning")
