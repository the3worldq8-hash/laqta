"""Test harness: a local HTTP 'CDN' serving fixture media + a fake provider.

The real platforms can't be reached from CI, so the fake provider returns the same
normalized structures the real providers produce, pointing at local files. Every other
layer (quality planning, jobs, ffmpeg, streaming, API, cleanup) runs for real.
"""
from __future__ import annotations

import functools
import http.server
import re
import threading
from pathlib import Path

import pytest

FIX = Path(__file__).parent / "fixtures"


class _Handler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a):  # quiet
        pass


@pytest.fixture(scope="session")
def cdn():
    handler = functools.partial(_Handler, directory=str(FIX))
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    yield f"http://127.0.0.1:{srv.server_address[1]}"
    srv.shutdown()


@pytest.fixture(scope="session")
def app_client(cdn, tmp_path_factory):
    import app.http as http_mod
    http_mod.host_allowed = lambda url: True  # local CDN is plain http on 127.0.0.1

    from app.models import MediaItem, Resolved, Variant
    from app.providers import PROVIDERS
    from app.providers.base import Provider
    from app.providers.ytdlp_util import formats_to_variants, make_ydl

    def size(name):
        return (FIX / name).stat().st_size

    class FakeProvider(Provider):
        name = "x"
        label = "Fake"
        url_patterns = (re.compile(r"https://fake\.test/"), re.compile(r"https://x\.com/demo_\w+/status/\d+"))
        hosts = ()

        async def resolve(self, url: str) -> Resolved:
            m = re.search(r"demo_(\w+)/status", url)
            kind = m.group(1) if m else url.rsplit("/", 1)[1]
            thumb = f"{cdn}/img1080.webp"
            if kind == "multi":  # X-like: three mp4 renditions, sizes unknown until HEAD
                items = [MediaItem(type="video", duration=6, thumbnail=thumb, variants=[
                    Variant(kind="direct", url=f"{cdn}/v1080.mp4", width=1080, height=1920, bitrate_kbps=11000, vcodec="avc1"),
                    Variant(kind="direct", url=f"{cdn}/v720.mp4", width=720, height=1280, bitrate_kbps=600, vcodec="avc1"),
                ])]
            elif kind == "single1080":  # one rendition only -> real transcode for Standard
                items = [MediaItem(type="video", duration=6, thumbnail=thumb, variants=[
                    Variant(kind="direct", url=f"{cdn}/v1080.mp4", width=1080, height=1920, bitrate_kbps=11000, vcodec="avc1")])]
            elif kind == "single720":  # modest single rendition -> no fake Standard
                items = [MediaItem(type="video", duration=6, thumbnail=thumb, variants=[
                    Variant(kind="direct", url=f"{cdn}/v720.mp4", width=720, height=1280, bitrate_kbps=600, vcodec="avc1")])]
            elif kind == "carousel":  # big photo + webp photo + video
                items = [
                    MediaItem(type="image", thumbnail=thumb, variants=[
                        Variant(kind="direct", url=f"{cdn}/img4000.jpg", width=4000, height=3000, ext="jpg", has_audio=False)]),
                    MediaItem(type="image", thumbnail=thumb, variants=[
                        Variant(kind="direct", url=f"{cdn}/img1080.webp", width=1080, height=1440, ext="webp", has_audio=False)]),
                    MediaItem(type="video", duration=6, thumbnail=thumb, variants=[
                        Variant(kind="direct", url=f"{cdn}/v720.mp4", width=720, height=1280, bitrate_kbps=600)]),
                ]
            elif kind == "ytdlp":  # TikTok/Instagram-like through real yt-dlp format processing
                ydl = make_ydl()
                info = {
                    "id": "777", "title": "t", "extractor": "generic", "extractor_key": "Generic",
                    "webpage_url": url, "duration": 6, "formats": [
                        {"format_id": "bytevc1_1080p", "url": f"{cdn}/v1080_hevc.mp4", "ext": "mp4", "width": 1080,
                         "height": 1920, "vcodec": "h265", "acodec": "aac", "tbr": 5200, "filesize": size("v1080_hevc.mp4")},
                        {"format_id": "h264_720p", "url": f"{cdn}/v720.mp4", "ext": "mp4", "width": 720, "height": 1280,
                         "vcodec": "h264", "acodec": "aac", "tbr": 650},
                        {"format_id": "download", "url": f"{cdn}/v720.mp4", "ext": "mp4", "format_note": "watermarked",
                         "width": 720, "height": 1280, "vcodec": "h264", "acodec": "aac"},
                    ]}
                processed = ydl.process_ie_result(info, download=False)
                items = [MediaItem(type="video", duration=6, thumbnail=thumb, variants=formats_to_variants(processed))]
                return Resolved(platform="tiktok", media_id="777", source_url=url, items=items, ydl=ydl)
            elif kind == "dash":  # Instagram-like: video-only + audio-only must be merged
                ydl = make_ydl()
                info = {
                    "id": "IGx", "title": "t", "extractor": "generic", "extractor_key": "Generic",
                    "webpage_url": url, "duration": 6, "formats": [
                        {"format_id": "dash-v1080", "url": f"{cdn}/vonly.mp4", "ext": "mp4", "width": 1080, "height": 1920,
                         "vcodec": "avc1.640028", "acodec": "none", "tbr": 9000},
                        {"format_id": "dash-a", "url": f"{cdn}/aonly.m4a", "ext": "m4a", "vcodec": "none",
                         "acodec": "mp4a.40.2", "tbr": 128},
                    ]}
                processed = ydl.process_ie_result(info, download=False)
                items = [MediaItem(type="video", duration=6, thumbnail=thumb, variants=formats_to_variants(processed))]
                return Resolved(platform="instagram", media_id="IGx", source_url=url, items=items, ydl=ydl)
            else:
                from app.providers.base import ProviderError
                raise ProviderError("not_found")
            return Resolved(platform="x", media_id=kind, source_url=url, title="caption", author="someone", items=items)

    PROVIDERS.insert(0, FakeProvider())

    from fastapi.testclient import TestClient
    from app.main import app
    with TestClient(app) as c:
        yield c
