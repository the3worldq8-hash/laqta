import json

import pytest

from app.models import MediaItem, Variant
from app.providers import clean_url, detect
from app.providers.tiktok import parse_item_struct, photo_items
from app.providers.x import _photo_variants, _video_variants, syndication_token
from app.quality import plan_item
from app.security import TokenError, host_allowed, sign, verify


@pytest.mark.parametrize("text,platform", [
    ("https://vm.tiktok.com/ZMabc123/", "tiktok"),
    ("https://vt.tiktok.com/ZSabc/", "tiktok"),
    ("https://www.tiktok.com/t/ZT8abc/", "tiktok"),
    ("https://www.tiktok.com/@a.b/video/7301234567890123456?is_from_webapp=1", "tiktok"),
    ("https://www.tiktok.com/@x/photo/7301234567890123456", "tiktok"),
    ("شوف https://www.instagram.com/reel/C8abcDEF12/?igsh=xx", "instagram"),
    ("https://www.instagram.com/p/C8abcDEF12/", "instagram"),
    ("https://www.instagram.com/username/p/C8abcDEF12/", "instagram"),
    ("https://www.instagram.com/share/reel/BAabc123", "instagram"),
    ("https://x.com/user/status/1834568916211286018?s=20", "x"),
    ("https://twitter.com/i/web/status/1834568916211286018", "x"),
    ("https://mobile.twitter.com/u/status/1834568916211286018/photo/1", "x"),
    ("https://t.co/AbC123", "x"),
    ("https://youtube.com/watch?v=1", None),
    ("https://evil.com/x.com/user/status/123456789", None),
])
def test_detect(text, platform):
    url = clean_url(text)
    p = detect(url)
    assert (p.name if p else None) == platform


def test_tokens():
    tok = sign({"c": "a", "i": 0, "q": "hq"})
    assert verify(tok)["q"] == "hq"
    raw, mac = tok.split(".")
    with pytest.raises(TokenError):
        verify(raw[:-2] + "AA." + mac)
    with pytest.raises(TokenError):
        verify(sign({"c": "a"}, ttl=-5))


def test_host_allowlist():
    assert host_allowed("https://video.twimg.com/a.mp4")
    assert host_allowed("https://scontent-lhr8-1.cdninstagram.com/v/x.jpg")
    assert not host_allowed("http://video.twimg.com/a.mp4")           # https only
    assert not host_allowed("https://169.254.169.254/latest/meta-data")  # SSRF
    assert not host_allowed("https://twimg.com.evil.com/x")
    assert not host_allowed("https://localhost/x")


def test_syndication_token_matches_js():
    # Values computed with Node: ((Number(id)/1e15)*Math.PI).toString(36).replace(/(0+|\.)/g,'')
    assert syndication_token("1834568916211286018") == "4g3gutq1ulu"
    assert syndication_token("20") == "6dq1a2xwd93"


def test_x_parsing():
    media = {"type": "video", "original_info": {"width": 1080, "height": 1920},
             "video_info": {"duration_millis": 10000, "variants": [
                 {"content_type": "application/x-mpegURL", "url": "https://video.twimg.com/a.m3u8"},
                 {"content_type": "video/mp4", "bitrate": 632000, "url": "https://video.twimg.com/ext_tw_video/1/pu/vid/avc1/320x568/a.mp4"},
                 {"content_type": "video/mp4", "bitrate": 2176000, "url": "https://video.twimg.com/ext_tw_video/1/pu/vid/avc1/720x1280/b.mp4"},
                 {"content_type": "video/mp4", "bitrate": 10368000, "url": "https://video.twimg.com/ext_tw_video/1/pu/vid/avc1/1080x1920/c.mp4"},
             ]}}
    variants, dur = _video_variants(media)
    assert dur == 10 and len(variants) == 3
    plans = plan_item(MediaItem(type="video", variants=variants, duration=dur))
    assert plans["hq"].height == 1920 and plans["standard"].height == 1280
    photos = _photo_variants("https://pbs.twimg.com/media/ABC.jpg", 4096, 3072)
    assert [p.label for p in photos] == ["orig", "large", "medium", "small"]
    plans = plan_item(MediaItem(type="image", variants=photos))
    assert plans["hq"].source.label == "orig" and plans["standard"].source.label == "large"
    small = _photo_variants("https://pbs.twimg.com/media/ABC.png", 1000, 800)
    assert [p.label for p in small] == ["orig", "small"]


def test_tiktok_photo_page_parsing():
    data = {"__DEFAULT_SCOPE__": {"webapp.video-detail": {"itemInfo": {"itemStruct": {
        "id": "1", "desc": "hi", "author": {"uniqueId": "me"},
        "imagePost": {"images": [
            {"imageURL": {"urlList": ["https://p16-sign.tiktokcdn.com/a~tplv-photomode-image.webp",
                                      "https://p16-sign.tiktokcdn.com/a~tplv-photomode-image.jpeg"]},
             "imageWidth": 1080, "imageHeight": 1440},
            {"imageURL": {"urlList": ["https://p16-sign.tiktokcdn.com/b~tplv-photomode-image.jpeg"]},
             "imageWidth": 1080, "imageHeight": 1920}]}}}}}}
    html = f'<html><script id="__UNIVERSAL_DATA_FOR_REHYDRATION__" type="application/json">{json.dumps(data)}</script>'
    items = photo_items(parse_item_struct(html))
    assert len(items) == 2 and items[0].variants[0].url.endswith(".jpeg") and items[0].variants[0].ext == "jpg"
    plans = plan_item(items[0])
    assert plans["standard"] is None and "single_quality" in plans["hq"].notes


def test_quality_never_upscales_and_prefers_real_renditions():
    v = lambda w, h, kbps, size=None, codec="avc1": Variant(kind="direct", url="https://x", width=w, height=h,
                                                            bitrate_kbps=kbps, filesize=size, vcodec=codec)
    # 540p source: HQ stays 540p and flagged as low; nothing upscaled
    plans = plan_item(MediaItem(type="video", variants=[v(540, 960, 900)], duration=10))
    assert plans["hq"].height == 960 and "source_low" in plans["hq"].notes and plans["standard"] is None
    # TikTok-like: 1080 HEVC + 720 h264 + 540 h264
    plans = plan_item(MediaItem(type="video", duration=10, variants=[
        v(1080, 1920, 1500, 1_900_000, "h265"), v(720, 1280, 1000, 1_250_000), v(540, 960, 600, 750_000)]))
    assert plans["hq"].height == 1920 and plans["hq"].method == "remux"
    assert plans["standard"].height == 1280 and plans["standard"].method == "stream"
    # Standard candidate too close in size to HQ is rejected -> transcode instead
    plans = plan_item(MediaItem(type="video", duration=10, variants=[
        v(1080, 1920, 3000, 4_000_000), v(720, 1280, 2900, 3_900_000)]))
    assert plans["standard"].method == "transcode"
