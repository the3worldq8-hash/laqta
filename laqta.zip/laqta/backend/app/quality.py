"""Turns a list of source renditions into two honest download choices.

Rules
- "hq" is always the best rendition the source actually serves; it is never upscaled
  or re-encoded (only remuxed/merged losslessly when needed for compatibility).
- "standard" must be materially smaller than "hq". It is a smaller source rendition when
  one exists; otherwise a real re-encode (lower resolution and/or bitrate). When the
  source only offers one modest quality, "standard" is reported as unavailable instead of
  pretending.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

from .models import MediaItem, Variant

Method = Literal["stream", "merge", "remux", "transcode", "resize", "convert"]

STD_VIDEO_SHORT_SIDE = 720
STD_IMAGE_LONG_SIDE = 1600
_STD_VIDEO_KBPS = {720: 1800, 540: 1100, 480: 900, 360: 600}
STD_AUDIO_KBPS = 96


@dataclass
class Plan:
    key: Literal["standard", "hq"]
    method: Method
    source: Variant
    width: int | None
    height: int | None
    bitrate_kbps: float | None
    size: int | None
    size_exact: bool
    ext: str
    params: dict = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)


def _dims_for_short_side(v: Variant, short: int) -> tuple[int | None, int | None]:
    if not (v.width and v.height):
        return None, short
    k = short / min(v.width, v.height)
    return round(v.width * k / 2) * 2, round(v.height * k / 2) * 2


def _dims_for_long_side(v: Variant, long: int) -> tuple[int | None, int | None]:
    if not (v.width and v.height):
        return None, None
    k = long / max(v.width, v.height)
    return round(v.width * k), round(v.height * k)


def _video_method(v: Variant) -> Method:
    if v.kind == "ytdlp" and len(v.formats) > 1:
        return "merge"
    if v.is_hevc:
        return "remux"  # retag hev1 -> hvc1 so iPhone Photos accepts it
    return "stream"


def _rank(v: Variant) -> tuple:
    return (v.short_side, v.bitrate_kbps or 0, v.size or 0, 0 if v.is_hevc else 1)


def _plan_from_variant(key, v: Variant, method: Method, ext: str) -> Plan:
    return Plan(key=key, method=method, source=v, width=v.width, height=v.height,
                bitrate_kbps=v.bitrate_kbps, size=v.size, size_exact=bool(v.filesize), ext=ext)


def _smaller_enough(cand: Variant, hq: Variant) -> bool:
    if cand.size and hq.size:
        return cand.size <= 0.8 * hq.size
    if cand.bitrate_kbps and hq.bitrate_kbps:
        return cand.bitrate_kbps <= 0.75 * hq.bitrate_kbps
    return cand.short_side and hq.short_side and cand.short_side <= 0.8 * hq.short_side


def plan_video(item: MediaItem) -> dict[str, Plan | None]:
    vids = [v for v in item.variants]
    hq_v = max(vids, key=_rank)
    hq = _plan_from_variant("hq", hq_v, _video_method(hq_v), "mp4")
    if hq_v.short_side and hq_v.short_side < 720:
        hq.notes.append("source_low")

    cands = [v for v in vids if v is not hq_v and v.short_side and _smaller_enough(v, hq_v)
             and v.short_side >= 360 and (v.short_side <= STD_VIDEO_SHORT_SIDE or
                                         (v.bitrate_kbps and hq_v.bitrate_kbps and v.bitrate_kbps <= 0.6 * hq_v.bitrate_kbps))]
    std: Plan | None = None
    if cands:
        best = max(cands, key=lambda v: (v.short_side, 0 if v.is_hevc else 1, v.bitrate_kbps or 0))
        std = _plan_from_variant("standard", best, _video_method(best), "mp4")
    elif hq_v.short_side > STD_VIDEO_SHORT_SIDE or (hq_v.bitrate_kbps or 0) > 2600:
        short = min(STD_VIDEO_SHORT_SIDE, hq_v.short_side or STD_VIDEO_SHORT_SIDE)
        tier = max(k for k in _STD_VIDEO_KBPS if k <= short) if short >= 360 else 360
        vk = _STD_VIDEO_KBPS[tier]
        if hq_v.bitrate_kbps:
            vk = min(vk, int(hq_v.bitrate_kbps * 0.6))
        w, h = _dims_for_short_side(hq_v, short)
        total = vk + (STD_AUDIO_KBPS if hq_v.has_audio else 0)
        est = int(total * 1000 / 8 * item.duration) if item.duration else None
        if est and hq_v.size:
            est = min(est, int(hq_v.size * 0.75))
        std = Plan(key="standard", method="transcode", source=hq_v, width=w, height=h, bitrate_kbps=total,
                   size=est, size_exact=False, ext="mp4",
                   params={"short_side": short, "video_kbps": vk, "audio": hq_v.has_audio},
                   notes=["transcoded"])
    return {"standard": std, "hq": hq}


def plan_image(item: MediaItem) -> dict[str, Plan | None]:
    imgs = item.variants
    hq_v = max(imgs, key=lambda v: (v.long_side, v.size or 0))
    needs_convert = hq_v.ext not in ("jpg", "jpeg", "png")
    hq = _plan_from_variant("hq", hq_v, "convert" if needs_convert else "stream",
                            "jpg" if needs_convert else ("png" if hq_v.ext == "png" else "jpg"))
    if needs_convert:
        hq.size_exact = False
        hq.params = {"quality": 95}
    if hq_v.long_side and hq_v.long_side < 1080:
        hq.notes.append("source_low")

    cands = [v for v in imgs if v is not hq_v and v.long_side and hq_v.long_side
             and v.long_side <= 0.8 * hq_v.long_side and v.long_side >= 600]
    std: Plan | None = None
    if cands:
        best = max(cands, key=lambda v: v.long_side)
        conv = best.ext not in ("jpg", "jpeg", "png")
        std = _plan_from_variant("standard", best, "convert" if conv else "stream", "jpg" if conv else best.ext)
        if conv:
            std.params = {"quality": 85}
            std.size_exact = False
    elif hq_v.long_side > STD_IMAGE_LONG_SIDE:
        w, h = _dims_for_long_side(hq_v, STD_IMAGE_LONG_SIDE)
        est = None
        if hq_v.size:
            est = int(hq_v.size * (STD_IMAGE_LONG_SIDE / hq_v.long_side) ** 2 * 0.75)
        std = Plan(key="standard", method="resize", source=hq_v, width=w, height=h, bitrate_kbps=None,
                   size=est, size_exact=False, ext="jpg",
                   params={"long_side": STD_IMAGE_LONG_SIDE, "quality": 82}, notes=["resized"])
    return {"standard": std, "hq": hq}


def plan_item(item: MediaItem) -> dict[str, Plan | None]:
    plans = plan_video(item) if item.type == "video" else plan_image(item)
    if plans["standard"] is None:
        plans["hq"].notes.append("single_quality")
    return plans
