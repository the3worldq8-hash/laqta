"""Download jobs: in-memory registry, temp-file lifecycle, upstream fetching with progress.

Nothing is persisted: temp files are deleted right after delivery, and a sweeper removes
anything left over (failed/abandoned) after LAQTA_JOB_TTL seconds.
"""
from __future__ import annotations

import asyncio
import logging
import secrets
import shutil
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

import httpx

from . import media
from .config import settings
from .http import BlockedHost, sync_client
from .models import Resolved, Variant
from .quality import Plan

log = logging.getLogger("laqta.jobs")

MIME = {"mp4": "video/mp4", "jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png",
        "webp": "image/webp", "heic": "image/heic"}


class JobError(Exception):
    def __init__(self, code: str, detail: str = "") -> None:
        super().__init__(detail or code)
        self.code = code


@dataclass
class CacheEntry:
    id: str
    resolved: Resolved
    plans: list[dict[str, Plan | None]]
    created: float = field(default_factory=time.time)


@dataclass
class Job:
    id: str
    entry: CacheEntry
    item_index: int
    plan: Plan
    filename: str
    state: str = "queued"          # queued | running | ready | error
    phase: str = "queued"          # fetching | processing | ready
    progress: float = 0.0          # progress of the current phase 0..1
    path: Path | None = None       # set for file-backed jobs
    size: int | None = None
    error: str | None = None
    created: float = field(default_factory=time.time)
    done: threading.Event = field(default_factory=threading.Event)

    @property
    def mime(self) -> str:
        return MIME.get(self.plan.ext, "application/octet-stream")

    @property
    def streams_live(self) -> bool:
        return self.plan.method == "stream"

    def public(self) -> dict:
        return {"id": self.id, "state": self.state, "phase": self.phase,
                "progress": round(self.progress, 4), "size": self.size, "error": self.error,
                "filename": self.filename, "mime": self.mime}


# --------------------------------------------------------------------------- fetching
def _check_size(n: int | None) -> None:
    if n and n > settings.max_file_bytes:
        raise JobError("too_large")


def fetch_direct(v: Variant, dest: Path, progress: Callable[[float], None]) -> int:
    try:
        with sync_client().stream("GET", v.url, headers={**v.headers, "Accept-Encoding": "identity"}) as r:
            if r.status_code >= 400:
                raise JobError("upstream", f"HTTP {r.status_code}")
            total = int(r.headers.get("content-length") or 0) or v.size
            _check_size(total)
            got = 0
            with dest.open("wb") as fh:
                for chunk in r.iter_bytes(256 * 1024):
                    fh.write(chunk)
                    got += len(chunk)
                    if got > settings.max_file_bytes:
                        raise JobError("too_large")
                    if total:
                        progress(min(1.0, got / total))
            return got
    except (httpx.HTTPError, BlockedHost) as exc:
        raise JobError("upstream", str(exc)) from exc


def open_ytdlp_stream(ydl: Any, fmt: dict):
    """Open an upstream response for a yt-dlp format using the same cookie jar/headers."""
    from yt_dlp.networking import Request
    headers = dict(fmt.get("http_headers") or {})
    return ydl.urlopen(Request(fmt["url"], headers=headers))


def fetch_ytdlp(ydl: Any, fmt: dict, dest: Path, progress: Callable[[float], None]) -> int:
    proto = fmt.get("protocol") or "https"
    if proto not in ("http", "https"):
        # Segmented (DASH fragments): let yt-dlp's own downloader handle it.
        state = {"p": 0.0}

        def hook(d: dict) -> None:
            if d.get("filename") and Path(d["filename"]).name.startswith(dest.stem):
                tot = d.get("total_bytes") or d.get("total_bytes_estimate")
                if tot and d.get("downloaded_bytes"):
                    state["p"] = d["downloaded_bytes"] / tot
                    progress(min(1.0, state["p"]))
        ydl.add_progress_hook(hook)
        try:
            ok = ydl.dl(str(dest), dict(fmt, _filename=str(dest)))
        except Exception as exc:
            raise JobError("upstream", str(exc)) from exc
        if not ok or not dest.exists():
            raise JobError("upstream", "fragment download failed")
        return dest.stat().st_size
    try:
        resp = open_ytdlp_stream(ydl, fmt)
    except Exception as exc:
        raise JobError("upstream", str(exc)) from exc
    with resp:
        total = int(resp.headers.get("Content-Length") or 0) or fmt.get("filesize") or fmt.get("filesize_approx")
        _check_size(total)
        got = 0
        with dest.open("wb") as fh:
            while True:
                chunk = resp.read(256 * 1024)
                if not chunk:
                    break
                fh.write(chunk)
                got += len(chunk)
                if got > settings.max_file_bytes:
                    raise JobError("too_large")
                if total:
                    progress(min(1.0, got / total))
    return got


def fetch_variant(resolved: Resolved, v: Variant, workdir: Path, progress: Callable[[float], None]) -> list[Path]:
    """Download every part of a variant (1 file, or video+audio) into workdir."""
    if v.kind == "direct":
        p = workdir / f"src0.{v.ext}"
        fetch_direct(v, p, progress)
        return [p]
    paths: list[Path] = []
    sizes = [f.get("filesize") or f.get("filesize_approx") or 1 for f in v.formats]
    total = sum(sizes)
    done = 0.0
    for i, fmt in enumerate(v.formats):
        p = workdir / f"src{i}.{fmt.get('ext') or 'mp4'}"
        share = sizes[i] / total
        fetch_ytdlp(resolved.ydl, fmt, p, lambda x, d=done, s=share: progress(d + x * s))
        done += share
        paths.append(p)
    return paths


# --------------------------------------------------------------------------- manager
class JobManager:
    def __init__(self) -> None:
        self._jobs: dict[str, Job] = {}
        self._cache: dict[str, CacheEntry] = {}
        self._sem = threading.BoundedSemaphore(settings.max_parallel_jobs)
        self._lock = threading.Lock()

    # resolve cache (metadata only — never media bytes)
    def put_entry(self, resolved: Resolved, plans: list[dict[str, Plan | None]]) -> CacheEntry:
        entry = CacheEntry(id=secrets.token_urlsafe(9), resolved=resolved, plans=plans)
        self._cache[entry.id] = entry
        return entry

    def entry(self, entry_id: str) -> CacheEntry | None:
        e = self._cache.get(entry_id)
        if e and time.time() - e.created > settings.resolve_cache_ttl:
            self._cache.pop(entry_id, None)
            return None
        return e

    def get(self, job_id: str) -> Job | None:
        return self._jobs.get(job_id)

    def create(self, entry: CacheEntry, item_index: int, key: str) -> Job:
        plan = entry.plans[item_index][key]
        if plan is None:
            raise JobError("unavailable")
        r = entry.resolved
        suffix = f"_{item_index + 1}" if len(r.items) > 1 else ""
        safe_id = "".join(c for c in r.media_id if c.isalnum() or c in "-_")[:40]
        filename = f"laqta_{r.platform}_{safe_id}{suffix}_{'HQ' if key == 'hq' else 'SD'}.{plan.ext}"
        job = Job(id=secrets.token_urlsafe(12), entry=entry, item_index=item_index, plan=plan, filename=filename)
        self._jobs[job.id] = job
        if job.streams_live:
            job.state, job.phase, job.progress = "ready", "ready", 1.0
            job.size = plan.size if plan.size_exact else None
            job.done.set()
        else:
            threading.Thread(target=self._run, args=(job,), daemon=True, name=f"job-{job.id}").start()
        return job

    def _run(self, job: Job) -> None:
        workdir = settings.tmp_dir / job.id
        with self._sem:
            job.state, job.phase = "running", "fetching"
            try:
                workdir.mkdir(parents=True, exist_ok=True)
                self._process(job, workdir)
                job.state, job.phase, job.progress = "ready", "ready", 1.0
            except JobError as exc:
                job.state, job.error = "error", exc.code
                log.info("job %s failed: %s", job.id, exc)
                shutil.rmtree(workdir, ignore_errors=True)
            except media.MediaError as exc:
                job.state, job.error = "error", "processing"
                log.warning("job %s processing failed: %s", job.id, exc)
                shutil.rmtree(workdir, ignore_errors=True)
            except Exception:  # pragma: no cover - safety net
                log.exception("job %s crashed", job.id)
                job.state, job.error = "error", "internal"
                shutil.rmtree(workdir, ignore_errors=True)
            finally:
                job.done.set()

    def _process(self, job: Job, workdir: Path) -> None:
        plan, res = job.plan, job.entry.resolved
        item = res.items[job.item_index]

        def set_p(x: float) -> None:
            job.progress = x

        srcs = fetch_variant(res, plan.source, workdir, set_p)
        job.phase, job.progress = "processing", 0.0
        out = workdir / job.filename
        if plan.method == "merge":
            media.merge(srcs[0], srcs[1] if len(srcs) > 1 else None, out, plan.source.is_hevc, item.duration, set_p)
        elif plan.method == "remux":
            media.merge(srcs[0], None, out, True, item.duration, set_p)
        elif plan.method == "transcode":
            media.transcode(srcs, out, plan.params["short_side"], plan.params["video_kbps"],
                            plan.params["audio"], item.duration, set_p)
        elif plan.method in ("resize", "convert"):
            media.image_to_jpeg(srcs[0], out, plan.params.get("long_side"), plan.params.get("quality", 90))
        else:  # pragma: no cover
            raise JobError("internal", f"unknown method {plan.method}")
        for s in srcs:
            s.unlink(missing_ok=True)
        job.path = out
        job.size = out.stat().st_size

    def release(self, job: Job) -> None:
        """Called after the file has been delivered: delete it immediately."""
        if job.path:
            shutil.rmtree(job.path.parent, ignore_errors=True)
            job.path = None
        self._jobs.pop(job.id, None)

    def sweep(self) -> None:
        now = time.time()
        for jid, job in list(self._jobs.items()):
            if now - job.created > settings.job_ttl and job.done.is_set():
                self.release(job)
        for eid, e in list(self._cache.items()):
            if now - e.created > settings.resolve_cache_ttl:
                self._cache.pop(eid, None)
        # orphaned dirs (e.g. after a crash/restart)
        for d in settings.tmp_dir.glob("*"):
            try:
                if now - d.stat().st_mtime > settings.job_ttl and d.name not in self._jobs:
                    shutil.rmtree(d, ignore_errors=True)
            except FileNotFoundError:
                pass

    async def sweeper(self) -> None:
        while True:
            await asyncio.sleep(60)
            await asyncio.to_thread(self.sweep)


jobs = JobManager()
