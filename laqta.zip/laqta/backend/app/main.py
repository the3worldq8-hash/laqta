"""HTTP API + static frontend."""
from __future__ import annotations

import asyncio
import contextlib
import logging
from typing import Any
from urllib.parse import quote

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from starlette.background import BackgroundTask
from starlette.concurrency import iterate_in_threadpool

from . import http as http_mod
from .config import settings
from .http import BlockedHost, client, head_size
from .jobs import CacheEntry, Job, JobError, jobs, open_ytdlp_stream
from .models import Resolved
from .providers import PROVIDERS, ProviderError, clean_url, detect
from .quality import Plan, plan_item
from .security import TokenError, rate_limiter, sign, verify

log = logging.getLogger("laqta")
# never log upstream/user URLs
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")


@contextlib.asynccontextmanager
async def lifespan(_: FastAPI):
    task = asyncio.create_task(jobs.sweeper())
    yield
    task.cancel()
    await http_mod.aclose()


app = FastAPI(title="Laqta", version="1.0.0", lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)

if settings.cors_origins:
    app.add_middleware(CORSMiddleware, allow_origins=list(settings.cors_origins), allow_methods=["GET", "POST"],
                       allow_headers=["Content-Type"], expose_headers=["Content-Length", "Content-Disposition"])

CSP = ("default-src 'self'; img-src 'self' blob: data:; media-src 'self' blob:; style-src 'self'; "
       "script-src 'self'; connect-src 'self'; font-src 'self'; manifest-src 'self'; "
       "frame-ancestors 'none'; base-uri 'none'; form-action 'self'")


@app.middleware("http")
async def security_headers(request: Request, call_next):
    resp = await call_next(request)
    resp.headers.setdefault("Content-Security-Policy", CSP)
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["Referrer-Policy"] = "no-referrer"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    if request.url.path.startswith("/api/"):
        resp.headers.setdefault("Cache-Control", "no-store")
    return resp


def client_ip(request: Request) -> str:
    if settings.trust_proxy:
        fwd = request.headers.get("x-forwarded-for")
        if fwd:
            return fwd.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def limit(request: Request, bucket: str, n: int) -> None:
    if not rate_limiter.check(bucket, client_ip(request), n):
        raise HTTPException(429, detail={"code": "rate_limited"})


def err(status: int, code: str) -> HTTPException:
    return HTTPException(status, detail={"code": code})


# ----------------------------------------------------------------------------- serialization
def res_label(w: int | None, h: int | None) -> str | None:
    if w and h:
        return f"{min(w, h)}p"
    return f"{h}p" if h else None


def option_json(entry: CacheEntry, idx: int, plan: Plan | None, item_type: str) -> dict | None:
    if plan is None:
        return None
    return {
        "token": sign({"c": entry.id, "i": idx, "q": plan.key}),
        "width": plan.width, "height": plan.height,
        "resolution": res_label(plan.width, plan.height) if item_type == "video" else None,
        "bitrate_kbps": round(plan.bitrate_kbps) if plan.bitrate_kbps else None,
        "size": plan.size, "size_exact": plan.size_exact,
        "ext": plan.ext, "method": plan.method, "notes": plan.notes,
    }


def entry_json(entry: CacheEntry) -> dict:
    r = entry.resolved
    items = []
    for i, (item, plans) in enumerate(zip(r.items, entry.plans)):
        items.append({
            "index": i, "type": item.type, "duration": item.duration,
            "thumb": f"/api/thumb/{sign({'c': entry.id, 'i': i})}" if item.thumbnail else None,
            "options": {k: option_json(entry, i, plans[k], item.type) for k in ("standard", "hq")},
        })
    title = (r.title or "").strip()
    return {"id": entry.id, "platform": r.platform, "author": r.author,
            "title": title[:280] + ("…" if len(title) > 280 else ""),
            "source_url": r.source_url, "items": items}


# ----------------------------------------------------------------------------- size discovery
async def _fill_sizes(resolved: Resolved, plans: list[dict[str, Plan | None]]) -> None:
    """Ask the CDN for exact byte counts of every offered rendition we don't know yet."""

    async def direct(plan: Plan) -> None:
        n = await head_size(plan.source.url, plan.source.headers)
        if n:
            plan.source.filesize = n
            if plan.method in ("stream", "remux", "merge", "convert"):
                if plan.method == "stream":
                    plan.size, plan.size_exact = n, True
                elif plan.method == "convert" and not plan.size:
                    plan.size = n
                else:
                    plan.size, plan.size_exact = n, False
            elif plan.method == "resize" and plan.source.long_side:
                plan.size = int(n * (plan.params["long_side"] / plan.source.long_side) ** 2 * 0.75)

    def ytdlp_sizes(plan: Plan) -> None:
        from yt_dlp.networking import HEADRequest
        total = 0
        for f in plan.source.formats:
            if f.get("filesize"):
                total += int(f["filesize"])
                continue
            try:
                with resolved.ydl.urlopen(HEADRequest(f["url"], headers=f.get("http_headers") or {})) as r:
                    n = int(r.headers.get("Content-Length") or 0)
            except Exception:
                return
            if not n:
                return
            total += n
        plan.source.filesize = total
        exact = plan.method == "stream"
        if plan.method in ("stream", "merge", "remux"):
            plan.size, plan.size_exact = total, exact

    tasks = []
    seen: set[int] = set()
    for plans_ in plans:
        for plan in plans_.values():
            if plan is None or id(plan) in seen:
                continue
            seen.add(id(plan))
            if plan.size_exact:
                continue
            if plan.source.kind == "direct" and plan.source.url:
                tasks.append(direct(plan))
            elif plan.source.kind == "ytdlp" and resolved.ydl is not None and plan.method != "transcode":
                tasks.append(asyncio.to_thread(ytdlp_sizes, plan))
    if tasks:
        with contextlib.suppress(asyncio.TimeoutError):
            await asyncio.wait_for(asyncio.gather(*tasks, return_exceptions=True), timeout=8)
    # Re-derive transcode estimates now that the HQ size may be known.
    for plans_ in plans:
        std, hq = plans_.get("standard"), plans_.get("hq")
        if std and hq and std.method == "transcode" and hq.size and std.size:
            std.size = min(std.size, int(hq.size * 0.75))


# ----------------------------------------------------------------------------- API
class ResolveIn(BaseModel):
    url: str = Field(..., max_length=2048)


class JobIn(BaseModel):
    token: str = Field(..., max_length=1024)


@app.get("/api/health")
async def health() -> dict:
    return {"ok": True}


@app.get("/api/platforms")
async def platforms() -> list[dict]:
    return [{"id": p.name, "label": p.label} for p in PROVIDERS]


async def do_resolve(raw: str) -> CacheEntry:
    url = clean_url(raw)
    if not url:
        raise err(400, "invalid_url")
    provider = detect(url)
    if not provider:
        raise err(400, "unsupported")
    try:
        resolved = await asyncio.wait_for(provider.resolve(url), timeout=45)
    except ProviderError as exc:
        status = {"not_found": 404, "private": 403, "unsupported": 400, "no_media": 404}.get(exc.code, 502)
        log.info("resolve failed platform=%s code=%s", provider.name, exc.code)
        raise err(status, exc.code) from exc
    except asyncio.TimeoutError as exc:
        raise err(504, "timeout") from exc
    for item in resolved.items:
        if item.duration and item.duration > settings.max_duration_s:
            raise err(413, "too_large")
    plans = [plan_item(it) for it in resolved.items]
    await _fill_sizes(resolved, plans)
    return jobs.put_entry(resolved, plans)


@app.post("/api/resolve")
async def resolve(body: ResolveIn, request: Request) -> dict:
    limit(request, "resolve", settings.rate_resolve_per_min)
    entry = await do_resolve(body.url)
    return entry_json(entry)


def _job_from_token(token: str) -> Job:
    try:
        data = verify(token)
    except TokenError as exc:
        raise err(400, "expired") from exc
    entry = jobs.entry(data["c"])
    if not entry:
        raise err(410, "expired")
    try:
        return jobs.create(entry, int(data["i"]), data["q"])
    except (JobError, IndexError, KeyError) as exc:
        raise err(400, "unavailable") from exc


@app.post("/api/jobs")
async def create_job(body: JobIn, request: Request) -> dict:
    limit(request, "jobs", settings.rate_jobs_per_min)
    return _job_from_token(body.token).public()


@app.get("/api/jobs/{job_id}")
async def job_status(job_id: str) -> dict:
    job = jobs.get(job_id)
    if not job:
        raise err(404, "expired")
    return job.public()


def _disposition(filename: str) -> str:
    return f"attachment; filename=\"{filename}\"; filename*=UTF-8''{quote(filename)}"


class _DeletingFileResponse(FileResponse):
    """Deletes the temp file once sent — also when the client disconnects mid-transfer."""

    def __init__(self, job: Job, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self._job = job

    async def __call__(self, scope, receive, send) -> None:
        try:
            await super().__call__(scope, receive, send)
        finally:
            await asyncio.to_thread(jobs.release, self._job)


async def _serve(job: Job) -> Response:
    if job.state == "error":
        raise err(502, job.error or "upstream")
    if job.state != "ready":
        raise err(409, "not_ready")
    headers = {"Content-Disposition": _disposition(job.filename), "Cache-Control": "no-store",
               "X-Laqta-Filename": job.filename}

    if job.path:  # file-backed: deliver then delete immediately
        path = job.path
        return _DeletingFileResponse(job, path, media_type=job.mime, headers=headers)

    v = job.plan.source
    if v.kind == "direct":
        c = client()
        try:
            req = c.build_request("GET", v.url, headers={**v.headers, "Accept-Encoding": "identity"})
            up = await c.send(req, stream=True)
        except (httpx.HTTPError, BlockedHost) as exc:
            raise err(502, "upstream") from exc
        if up.status_code >= 400:
            await up.aclose()
            raise err(502, "upstream")
        length = up.headers.get("content-length")
        if length and int(length) > settings.max_file_bytes:
            await up.aclose()
            raise err(413, "too_large")
        if length:
            headers["Content-Length"] = length

        async def cleanup() -> None:
            await up.aclose()
            jobs.release(job)
        return StreamingResponse(up.aiter_raw(256 * 1024), media_type=job.mime, headers=headers,
                                 background=BackgroundTask(cleanup))

    # yt-dlp progressive format: stream through yt-dlp's networking (keeps cookies/headers)
    fmt = v.formats[0]
    try:
        up = await asyncio.to_thread(open_ytdlp_stream, job.entry.resolved.ydl, fmt)
    except Exception as exc:
        raise err(502, "upstream") from exc
    length = up.headers.get("Content-Length")
    if length:
        if int(length) > settings.max_file_bytes:
            up.close()
            raise err(413, "too_large")
        headers["Content-Length"] = length

    def gen():
        while True:
            chunk = up.read(256 * 1024)
            if not chunk:
                break
            yield chunk

    def cleanup_sync() -> None:
        with contextlib.suppress(Exception):
            up.close()
        jobs.release(job)
    return StreamingResponse(iterate_in_threadpool(gen()), media_type=job.mime, headers=headers,
                             background=BackgroundTask(cleanup_sync))


@app.get("/api/jobs/{job_id}/file")
async def job_file(job_id: str) -> Response:
    job = jobs.get(job_id)
    if not job:
        raise err(404, "expired")
    return await _serve(job)


@app.get("/api/thumb/{token}")
async def thumb(token: str) -> Response:
    try:
        data = verify(token)
    except TokenError as exc:
        raise err(400, "expired") from exc
    entry = jobs.entry(data["c"])
    if not entry or data["i"] >= len(entry.resolved.items):
        raise err(410, "expired")
    item = entry.resolved.items[data["i"]]
    try:
        r = await client().get(item.thumbnail, headers=item.thumbnail_headers)
    except (httpx.HTTPError, BlockedHost) as exc:
        raise err(502, "upstream") from exc
    ctype = r.headers.get("content-type", "image/jpeg")
    if r.status_code >= 400 or not ctype.startswith("image/") or len(r.content) > 15 * 1024 * 1024:
        raise err(502, "upstream")
    return Response(r.content, media_type=ctype, headers={"Cache-Control": "private, max-age=900"})


# ----------------------------------------------------------------------------- one-shot (Shortcuts / native app)
@app.get("/api/shortcut")
async def shortcut(url: str, request: Request, q: str = "hq") -> dict:
    """For the iOS Shortcut / native app: resolve and return one direct file URL per item."""
    limit(request, "resolve", settings.rate_resolve_per_min)
    key = "standard" if q in ("standard", "sd", "std") else "hq"
    entry = await do_resolve(url)
    base = str(request.base_url).rstrip("/")
    files = []
    for i, plans in enumerate(entry.plans):
        k = key if plans.get(key) else "hq"
        files.append({"url": f"{base}/api/fetch/{sign({'c': entry.id, 'i': i, 'q': k})}",
                      "type": entry.resolved.items[i].type, "quality": k})
    return {"platform": entry.resolved.platform, "count": len(files), "files": files,
            "urls": [f["url"] for f in files]}


@app.get("/api/fetch/{token}")
async def fetch_once(token: str, request: Request) -> Response:
    """Create a job, wait for it, and return the file in one request."""
    limit(request, "jobs", settings.rate_jobs_per_min)
    job = _job_from_token(token)
    await asyncio.to_thread(job.done.wait, 900)
    return await _serve(job)


@app.exception_handler(HTTPException)
async def http_exc(_: Request, exc: HTTPException) -> JSONResponse:
    detail: Any = exc.detail if isinstance(exc.detail, dict) else {"code": str(exc.detail)}
    return JSONResponse(detail, status_code=exc.status_code)


# ----------------------------------------------------------------------------- static frontend
if settings.frontend_dir.is_dir():
    app.mount("/", StaticFiles(directory=settings.frontend_dir, html=True), name="frontend")
