"""Normalized media model shared by every provider."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

MediaType = Literal["video", "image"]
VariantKind = Literal["direct", "ytdlp"]


@dataclass
class Variant:
    """One concrete rendition offered by the source platform."""

    kind: VariantKind
    width: int | None = None
    height: int | None = None
    bitrate_kbps: float | None = None      # total (video+audio) bitrate when known
    filesize: int | None = None            # exact bytes when known
    filesize_approx: int | None = None     # estimate when exact size unknown
    ext: str = "mp4"
    vcodec: str | None = None
    has_audio: bool = True
    # kind == "direct": a plain URL fetched with these headers
    url: str | None = None
    headers: dict[str, str] = field(default_factory=dict)
    # kind == "ytdlp": processed yt-dlp format dicts (1 = progressive, 2 = video+audio)
    formats: list[dict[str, Any]] = field(default_factory=list)
    label: str | None = None

    @property
    def short_side(self) -> int:
        if self.width and self.height:
            return min(self.width, self.height)
        return self.height or self.width or 0

    @property
    def long_side(self) -> int:
        return max(self.width or 0, self.height or 0)

    @property
    def size(self) -> int | None:
        return self.filesize or self.filesize_approx

    @property
    def is_hevc(self) -> bool:
        c = (self.vcodec or "").lower()
        return c.startswith(("hev", "hvc", "h265", "bytevc1"))


@dataclass
class MediaItem:
    type: MediaType
    variants: list[Variant]
    thumbnail: str | None = None
    thumbnail_headers: dict[str, str] = field(default_factory=dict)
    duration: float | None = None


@dataclass
class Resolved:
    platform: str
    media_id: str
    source_url: str
    items: list[MediaItem]
    title: str | None = None
    author: str | None = None
    # Live yt-dlp instance whose cookie jar is needed to download its formats.
    ydl: Any = None
