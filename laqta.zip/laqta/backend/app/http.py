"""Shared HTTP clients. Every request (and every redirect hop) is host-checked."""
from __future__ import annotations

import httpx

from .config import USER_AGENT, settings
from .security import host_allowed


class BlockedHost(Exception):
    pass


async def _guard_async(request: httpx.Request) -> None:
    if not host_allowed(str(request.url)):
        raise BlockedHost(request.url.host)


def _guard_sync(request: httpx.Request) -> None:
    if not host_allowed(str(request.url)):
        raise BlockedHost(request.url.host)


_LIMITS = httpx.Limits(max_connections=200, max_keepalive_connections=40)
_TIMEOUT = httpx.Timeout(settings.upstream_timeout, connect=10)

_async_client: httpx.AsyncClient | None = None
_sync_client: httpx.Client | None = None


def client() -> httpx.AsyncClient:
    global _async_client
    if _async_client is None:
        _async_client = httpx.AsyncClient(
            http2=False, follow_redirects=True, max_redirects=6, timeout=_TIMEOUT, limits=_LIMITS,
            headers={"User-Agent": USER_AGENT, "Accept-Language": "en-US,en;q=0.9"},
            event_hooks={"request": [_guard_async]},
        )
    return _async_client


def sync_client() -> httpx.Client:
    global _sync_client
    if _sync_client is None:
        _sync_client = httpx.Client(
            follow_redirects=True, max_redirects=6, timeout=_TIMEOUT, limits=_LIMITS,
            headers={"User-Agent": USER_AGENT}, event_hooks={"request": [_guard_sync]},
        )
    return _sync_client


async def head_size(url: str, headers: dict[str, str]) -> int | None:
    """Content-Length via HEAD (fallback: 1-byte ranged GET)."""
    c = client()
    try:
        r = await c.head(url, headers=headers)
        if r.status_code < 400 and r.headers.get("content-length", "").isdigit():
            n = int(r.headers["content-length"])
            if n > 0:
                return n
        r = await c.get(url, headers={**headers, "Range": "bytes=0-0"})
        cr = r.headers.get("content-range", "")
        if "/" in cr and cr.rsplit("/", 1)[1].isdigit():
            return int(cr.rsplit("/", 1)[1])
    except (httpx.HTTPError, BlockedHost):
        return None
    return None


async def aclose() -> None:
    global _async_client, _sync_client
    if _async_client:
        await _async_client.aclose()
        _async_client = None
    if _sync_client:
        _sync_client.close()
        _sync_client = None
