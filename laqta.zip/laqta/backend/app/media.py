"""ffmpeg / Pillow processing with progress callbacks. All functions are blocking."""
from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Callable

from PIL import Image, ImageOps

from .config import settings

Progress = Callable[[float], None]


class MediaError(Exception):
    pass


def _run_ffmpeg(args: list[str], duration: float | None, progress: Progress | None) -> None:
    cmd = [settings.ffmpeg, "-hide_banner", "-loglevel", "error", "-nostdin", "-y",
           "-progress", "pipe:1", "-nostats", *args]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    assert proc.stdout is not None
    for line in proc.stdout:
        if progress and duration and line.startswith("out_time_us="):
            try:
                us = int(line.split("=", 1)[1])
                progress(max(0.0, min(1.0, us / 1e6 / duration)))
            except ValueError:
                pass
    err = proc.stderr.read() if proc.stderr else ""
    if proc.wait() != 0:
        raise MediaError(err.strip()[-400:] or "ffmpeg failed")
    if progress:
        progress(1.0)


def merge(video: Path, audio: Path | None, out: Path, hevc: bool, duration: float | None,
          progress: Progress | None = None) -> None:
    """Lossless mux (no re-encode) into an MP4 that iOS Photos & Android galleries accept."""
    args = ["-i", str(video)]
    if audio:
        args += ["-i", str(audio), "-map", "0:v:0", "-map", "1:a:0"]
    else:
        args += ["-map", "0:v:0", "-map", "0:a?"]
    args += ["-c", "copy"]
    if hevc:
        args += ["-tag:v", "hvc1"]
    args += ["-movflags", "+faststart", str(out)]
    _run_ffmpeg(args, duration, progress)


def transcode(inputs: list[Path], out: Path, short_side: int, video_kbps: int, audio: bool,
              duration: float | None, progress: Progress | None = None) -> None:
    """Real Standard rendition: H.264 at <= short_side, capped bitrate, AAC 96k."""
    scale = (f"scale='if(gte(iw,ih),-2,min({short_side},iw))':'if(gte(iw,ih),min({short_side},ih),-2)'"
             ":flags=lanczos")
    args: list[str] = []
    for p in inputs:
        args += ["-i", str(p)]
    args += ["-map", "0:v:0"]
    if audio:
        args += ["-map", f"{1 if len(inputs) > 1 else 0}:a:0?"]
    args += ["-vf", scale, "-c:v", "libx264", "-preset", "veryfast", "-profile:v", "high",
             "-pix_fmt", "yuv420p", "-crf", "23", "-maxrate", f"{video_kbps}k", "-bufsize", f"{video_kbps * 2}k"]
    if audio:
        args += ["-c:a", "aac", "-b:a", "96k", "-ac", "2"]
    else:
        args += ["-an"]
    args += ["-movflags", "+faststart", str(out)]
    _run_ffmpeg(args, duration, progress)


def image_to_jpeg(src: Path, out: Path, long_side: int | None, quality: int) -> tuple[int, int]:
    try:
        with Image.open(src) as im:
            im = ImageOps.exif_transpose(im)
            if im.mode not in ("RGB", "L"):
                bg = Image.new("RGB", im.size, (255, 255, 255))
                im = im.convert("RGBA")
                bg.paste(im, mask=im.split()[-1])
                im = bg
            if long_side and max(im.size) > long_side:
                im.thumbnail((long_side, long_side), Image.Resampling.LANCZOS)
            im.save(out, "JPEG", quality=quality, optimize=True, progressive=True)
            return im.size
    except OSError as exc:
        raise MediaError(f"image decode failed: {exc}") from exc


def probe(path: Path) -> dict:
    """Width/height/duration/bitrate of a produced file (used in tests and logging)."""
    import json
    out = subprocess.run(["ffprobe", "-v", "error", "-print_format", "json", "-show_format", "-show_streams",
                          str(path)], capture_output=True, text=True, check=True).stdout
    return json.loads(out)
