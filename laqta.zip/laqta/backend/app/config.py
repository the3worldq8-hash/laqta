"""Runtime configuration, read once from environment variables."""
from __future__ import annotations

import os
import secrets
import tempfile
from dataclasses import dataclass, field
from pathlib import Path


def _int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except ValueError:
        return default


def _path(name: str) -> Path | None:
    value = os.environ.get(name, "").strip()
    return Path(value) if value else None


@dataclass(frozen=True)
class Settings:
    # HMAC key for signed download tokens. Set it in production so tokens survive restarts.
    secret_key: str = field(default_factory=lambda: os.environ.get("LAQTA_SECRET") or secrets.token_hex(32))
    # Scratch space for merges/transcodes. Files are deleted right after delivery.
    tmp_dir: Path = field(default_factory=lambda: Path(os.environ.get("LAQTA_TMP", tempfile.gettempdir())) / "laqta")
    max_file_bytes: int = field(default_factory=lambda: _int("LAQTA_MAX_MB", 1024) * 1024 * 1024)
    max_duration_s: int = field(default_factory=lambda: _int("LAQTA_MAX_DURATION", 3 * 60 * 60))
    resolve_cache_ttl: int = field(default_factory=lambda: _int("LAQTA_CACHE_TTL", 20 * 60))
    job_ttl: int = field(default_factory=lambda: _int("LAQTA_JOB_TTL", 15 * 60))
    max_parallel_jobs: int = field(default_factory=lambda: _int("LAQTA_MAX_JOBS", 4))
    rate_resolve_per_min: int = field(default_factory=lambda: _int("LAQTA_RATE_RESOLVE", 30))
    rate_jobs_per_min: int = field(default_factory=lambda: _int("LAQTA_RATE_JOBS", 60))
    upstream_timeout: int = field(default_factory=lambda: _int("LAQTA_TIMEOUT", 25))
    # Optional Netscape cookies files (only needed if a platform starts gating public posts).
    instagram_cookies: Path | None = field(default_factory=lambda: _path("LAQTA_IG_COOKIES"))
    tiktok_cookies: Path | None = field(default_factory=lambda: _path("LAQTA_TT_COOKIES"))
    x_cookies: Path | None = field(default_factory=lambda: _path("LAQTA_X_COOKIES"))
    frontend_dir: Path = field(default_factory=lambda: Path(os.environ.get(
        "LAQTA_FRONTEND", Path(__file__).resolve().parents[2] / "frontend")))
    # Trust X-Forwarded-For from a reverse proxy (Caddy/Nginx) for rate limiting.
    trust_proxy: bool = field(default_factory=lambda: os.environ.get("LAQTA_TRUST_PROXY", "1") == "1")
    cors_origins: tuple[str, ...] = field(default_factory=lambda: tuple(
        o.strip() for o in os.environ.get("LAQTA_CORS", "").split(",") if o.strip()))
    ffmpeg: str = field(default_factory=lambda: os.environ.get("LAQTA_FFMPEG", "ffmpeg"))


settings = Settings()
settings.tmp_dir.mkdir(parents=True, exist_ok=True)

USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)
