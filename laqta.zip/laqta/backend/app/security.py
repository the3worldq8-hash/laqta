"""Signed tokens, rate limiting and upstream host allowlisting (SSRF guard)."""
from __future__ import annotations

import base64
import hashlib
import hmac
import ipaddress
import json
import time
from collections import defaultdict, deque
from urllib.parse import urlsplit

from .config import settings


class TokenError(ValueError):
    pass


def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def _unb64(text: str) -> bytes:
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


def sign(payload: dict, ttl: int | None = None) -> str:
    body = dict(payload, exp=int(time.time()) + (ttl or settings.resolve_cache_ttl))
    raw = _b64(json.dumps(body, separators=(",", ":")).encode())
    mac = hmac.new(settings.secret_key.encode(), raw.encode(), hashlib.sha256).digest()[:18]
    return f"{raw}.{_b64(mac)}"


def verify(token: str) -> dict:
    try:
        raw, mac = token.split(".", 1)
        expected = hmac.new(settings.secret_key.encode(), raw.encode(), hashlib.sha256).digest()[:18]
        if not hmac.compare_digest(_unb64(mac), expected):
            raise TokenError("bad signature")
        body = json.loads(_unb64(raw))
    except TokenError:
        raise
    except Exception as exc:  # malformed
        raise TokenError("malformed token") from exc
    if body.get("exp", 0) < time.time():
        raise TokenError("expired")
    return body


# ---------------------------------------------------------------- hosts
# Only these host suffixes may ever be fetched by the server. Providers add theirs.
_ALLOWED_SUFFIXES: set[str] = set()


def allow_hosts(*suffixes: str) -> None:
    _ALLOWED_SUFFIXES.update(s.lower().lstrip(".") for s in suffixes)


def host_allowed(url: str) -> bool:
    try:
        parts = urlsplit(url)
    except ValueError:
        return False
    if parts.scheme != "https" or not parts.hostname:
        return False
    host = parts.hostname.lower()
    try:  # never raw IPs
        ipaddress.ip_address(host)
        return False
    except ValueError:
        pass
    return any(host == s or host.endswith("." + s) for s in _ALLOWED_SUFFIXES)


# ---------------------------------------------------------------- rate limit
class RateLimiter:
    """Sliding one-minute window per client key. In-memory: fine for one process."""

    def __init__(self) -> None:
        self._hits: dict[tuple[str, str], deque[float]] = defaultdict(deque)

    def check(self, bucket: str, key: str, limit: int) -> bool:
        now = time.monotonic()
        q = self._hits[(bucket, key)]
        while q and now - q[0] > 60:
            q.popleft()
        if len(q) >= limit:
            return False
        q.append(now)
        if len(self._hits) > 50_000:  # bound memory under abuse
            self._hits.clear()
        return True


rate_limiter = RateLimiter()
