"""Instagram: posts, reels and carousels (videos + images) via yt-dlp's Instagram extractor."""
from __future__ import annotations

import re

import httpx

from ..config import settings
from ..http import BlockedHost, client
from ..models import Resolved
from . import ytdlp_util
from .base import Provider, ProviderError

_POST = re.compile(r"https?://(?:www\.|m\.)?(?:instagram\.com|instagr\.am)/(?:[\w.]+/)?(p|reels?|tv)/([\w\-]{5,})", re.I)
_SHARE = re.compile(r"https?://(?:www\.)?instagram\.com/share/(?:p/|reel/)?[\w\-]+", re.I)
_STORY = re.compile(r"https?://(?:www\.)?instagram\.com/stories/", re.I)


class InstagramProvider(Provider):
    name = "instagram"
    label = "Instagram"
    url_patterns = (_POST, _SHARE, _STORY)
    hosts = ("instagram.com", "instagr.am", "cdninstagram.com", "fbcdn.net")

    async def _expand(self, url: str) -> str:
        if _POST.search(url):
            return url
        if _STORY.search(url):
            raise ProviderError("private", "stories require an account")
        try:
            r = await client().get(url, follow_redirects=False)
            loc = r.headers.get("location", "")
        except (httpx.HTTPError, BlockedHost) as exc:
            raise ProviderError("upstream", str(exc)) from exc
        if not _POST.search(loc):
            raise ProviderError("not_found", "share link did not resolve to a post")
        return loc

    async def resolve(self, url: str) -> Resolved:
        url = await self._expand(url)
        kind, code = _POST.search(url).groups()
        path = "reel" if kind.lower().startswith("reel") else "p"
        res = await ytdlp_util.extract(f"https://www.instagram.com/{path}/{code}/", self.name,
                                       settings.instagram_cookies)
        res.media_id = code
        return res
