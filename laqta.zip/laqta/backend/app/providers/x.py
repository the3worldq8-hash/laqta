"""X (Twitter): public embed (syndication) API, falls back to yt-dlp."""
from __future__ import annotations

import math
import re

import httpx

from ..config import settings
from ..http import BlockedHost, client
from ..models import MediaItem, Resolved, Variant
from . import ytdlp_util
from .base import Provider, ProviderError

_STATUS = re.compile(
    r"https?://(?:www\.|mobile\.|m\.)?(?:x|twitter|fxtwitter|vxtwitter|fixupx)\.com/"
    r"(?:[^/]+|i(?:/web)?)/status(?:es)?/(\d{5,25})", re.I)
_SHORT = re.compile(r"https?://t\.co/[A-Za-z0-9]+", re.I)
_RES_IN_URL = re.compile(r"/(\d{2,5})x(\d{2,5})/")


def _js_base36(value: float) -> str:
    """Port of V8's DoubleToRadixCString(value, 36) — exactly what JS `n.toString(36)` prints."""
    digits = "0123456789abcdefghijklmnopqrstuvwxyz"
    integer = math.floor(value)
    fraction = value - integer
    delta = max(0.5 * (math.nextafter(value, math.inf) - value), math.nextafter(0.0, 1.0))
    frac_digits: list[int] = []
    if fraction >= delta:
        while True:
            fraction *= 36
            delta *= 36
            d = int(fraction)
            frac_digits.append(d)
            fraction -= d
            if fraction > 0.5 or (fraction == 0.5 and (d & 1)):
                if fraction + delta > 1:
                    # round up, propagating carries
                    i = len(frac_digits) - 1
                    while True:
                        if i < 0:
                            integer += 1
                            break
                        frac_digits[i] += 1
                        if frac_digits[i] < 36:
                            break
                        frac_digits.pop()
                        i -= 1
                    break
            if fraction < delta:
                break
    int_part = ""
    n = int(integer)
    while True:
        n, r = divmod(n, 36)
        int_part = digits[r] + int_part
        if n == 0:
            break
    return int_part + ("." + "".join(digits[d] for d in frac_digits) if frac_digits else "")


def syndication_token(tweet_id: str) -> str:
    return re.sub(r"(0+|\.)", "", _js_base36(int(tweet_id) / 1e15 * math.pi))


def _photo_variants(base: str, w: int | None, h: int | None) -> list[Variant]:
    base = base.split("?")[0]
    stem, _, ext = base.rpartition(".")
    fmt = "png" if ext.lower() == "png" else "jpg"
    out = []
    for name, box in (("orig", None), ("large", 2048), ("medium", 1200), ("small", 680)):
        vw, vh = w, h
        if box and w and h and max(w, h) > box:
            k = box / max(w, h)
            vw, vh = round(w * k), round(h * k)
        elif box and w and h:
            continue  # this size would equal the original – skip duplicate
        out.append(Variant(kind="direct", url=f"{stem}?format={fmt}&name={name}", width=vw, height=vh,
                           ext=fmt, has_audio=False, label=name))
    return out


def _video_variants(media: dict) -> tuple[list[Variant], float | None]:
    info = media.get("video_info") or {}
    duration = (info.get("duration_millis") or 0) / 1000 or None
    orig = media.get("original_info") or {}
    out = []
    for v in info.get("variants") or []:
        if v.get("content_type") != "video/mp4" or not v.get("url"):
            continue
        m = _RES_IN_URL.search(v["url"])
        w, h = (int(m.group(1)), int(m.group(2))) if m else (orig.get("width"), orig.get("height"))
        kbps = (v.get("bitrate") or 0) / 1000 or None
        approx = int(kbps * 1000 / 8 * duration * 1.03) if kbps and duration else None
        out.append(Variant(kind="direct", url=v["url"], width=w, height=h, bitrate_kbps=kbps,
                           filesize_approx=approx, ext="mp4", vcodec="avc1",
                           has_audio=media.get("type") == "video"))
    return out, duration


class XProvider(Provider):
    name = "x"
    label = "X"
    url_patterns = (_STATUS, _SHORT)
    hosts = ("x.com", "twitter.com", "t.co", "twimg.com", "fxtwitter.com", "vxtwitter.com", "fixupx.com")

    async def _expand(self, url: str) -> str:
        if _STATUS.search(url):
            return url
        try:
            r = await client().get(url, follow_redirects=False)
            loc = r.headers.get("location") or ""
            if not loc:
                m = re.search(r'URL=([^"]+)"', r.text)
                loc = m.group(1) if m else ""
        except (httpx.HTTPError, BlockedHost) as exc:
            raise ProviderError("upstream", str(exc)) from exc
        if not _STATUS.search(loc):
            raise ProviderError("unsupported", "short link does not point to a post")
        return loc

    async def resolve(self, url: str) -> Resolved:
        url = await self._expand(url)
        tweet_id = _STATUS.search(url).group(1)
        try:
            return await self._syndication(tweet_id)
        except ProviderError as exc:
            if exc.code in ("not_found",):
                raise
            # Embed API refused (e.g. sensitive media) – let yt-dlp try with its guest flow.
            return await ytdlp_util.extract(f"https://x.com/i/status/{tweet_id}", self.name, settings.x_cookies)

    async def _syndication(self, tweet_id: str) -> Resolved:
        try:
            r = await client().get(
                "https://cdn.syndication.twimg.com/tweet-result",
                params={"id": tweet_id, "token": syndication_token(tweet_id), "lang": "en"},
            )
        except (httpx.HTTPError, BlockedHost) as exc:
            raise ProviderError("upstream", str(exc)) from exc
        if r.status_code == 404:
            raise ProviderError("not_found")
        if r.status_code != 200 or not r.content:
            raise ProviderError("upstream", f"status {r.status_code}")
        data = r.json()
        if data.get("__typename") == "TweetTombstone":
            raise ProviderError("private", "tombstone")
        # quoted tweet media is not this post's media; use only mediaDetails of the tweet itself
        medias = data.get("mediaDetails") or []
        items: list[MediaItem] = []
        for m in medias:
            thumb = m.get("media_url_https")
            orig = m.get("original_info") or {}
            if m.get("type") == "photo" and thumb:
                items.append(MediaItem(type="image", thumbnail=f"{thumb.split('?')[0]}?format=jpg&name=small",
                                       variants=_photo_variants(thumb, orig.get("width"), orig.get("height"))))
            elif m.get("type") in ("video", "animated_gif"):
                variants, duration = _video_variants(m)
                if variants:
                    items.append(MediaItem(type="video", thumbnail=thumb, variants=variants, duration=duration))
        if not items:
            raise ProviderError("no_media")
        user = data.get("user") or {}
        return Resolved(platform=self.name, media_id=tweet_id,
                        source_url=f"https://x.com/{user.get('screen_name', 'i')}/status/{tweet_id}",
                        title=data.get("text"), author=user.get("screen_name"), items=items)
