"""TikTok: videos via yt-dlp (no-watermark renditions), photo slideshows via page data."""
from __future__ import annotations

import asyncio
import json
import re

import httpx

from ..config import USER_AGENT, settings
from ..http import BlockedHost, client
from ..models import MediaItem, Resolved, Variant
from . import ytdlp_util
from .base import Provider, ProviderError

_POST = re.compile(r"https?://(?:www\.|m\.)?tiktok\.com/(?:@[\w.\-]*/)?(video|photo|v)/(\d{6,25})", re.I)
_SHORT = re.compile(r"https?://(?:vm|vt)\.tiktok\.com/[\w\-]+|https?://(?:www\.)?tiktok\.com/t/[\w\-]+", re.I)
_DATA = re.compile(r'<script[^>]+id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>(.*?)</script>', re.S)
_SIGI = re.compile(r'<script[^>]+id="SIGI_STATE"[^>]*>(.*?)</script>', re.S)
_HEADERS = {"User-Agent": USER_AGENT, "Referer": "https://www.tiktok.com/"}


def parse_item_struct(html: str) -> dict | None:
    m = _DATA.search(html)
    if m:
        try:
            scope = json.loads(m.group(1)).get("__DEFAULT_SCOPE__", {})
            item = scope.get("webapp.video-detail", {}).get("itemInfo", {}).get("itemStruct")
            if item:
                return item
        except json.JSONDecodeError:
            pass
    m = _SIGI.search(html)
    if m:
        try:
            items = json.loads(m.group(1)).get("ItemModule", {})
            return next(iter(items.values()), None)
        except json.JSONDecodeError:
            pass
    return None


def photo_items(item: dict) -> list[MediaItem]:
    out = []
    for img in (item.get("imagePost") or {}).get("images") or []:
        urls = ((img.get("imageURL") or {}).get("urlList")) or []
        if not urls:
            continue
        # prefer a JPEG rendition: iOS Photos and every gallery import it natively
        url = next((u for u in urls if ".jpeg" in u or ".jpg" in u or "jpeg" in u), urls[0])
        ext = "jpg" if ("jpeg" in url or ".jpg" in url) else ("webp" if "webp" in url else "jpg")
        w, h = img.get("imageWidth"), img.get("imageHeight")
        out.append(MediaItem(type="image", thumbnail=url, thumbnail_headers=dict(_HEADERS), variants=[
            Variant(kind="direct", url=url, width=w, height=h, ext=ext, has_audio=False, headers=dict(_HEADERS))]))
    return out


class TikTokProvider(Provider):
    name = "tiktok"
    label = "TikTok"
    url_patterns = (_POST, _SHORT)
    hosts = ("tiktok.com", "tiktokcdn.com", "tiktokcdn-us.com", "tiktokcdn-eu.com", "tiktokv.com",
             "tiktokv.us", "tiktokv.eu", "tiktokw.us", "byteoversea.com", "ibytedtos.com",
             "ibyteimg.com", "muscdn.com", "akamaized.net")

    async def _expand(self, url: str) -> str:
        if _POST.search(url):
            return url
        try:
            r = await client().get(url, follow_redirects=False, headers=_HEADERS)
            loc = r.headers.get("location", "")
            if not loc and r.status_code < 300:
                loc = str(r.url)
        except (httpx.HTTPError, BlockedHost) as exc:
            raise ProviderError("upstream", str(exc)) from exc
        if not _POST.search(loc):
            raise ProviderError("not_found", "short link did not resolve to a post")
        return loc

    async def _fetch_page(self, url: str) -> str:
        """Fetch the post page, impersonating a browser through yt-dlp's networking stack."""
        def _get() -> str:
            from yt_dlp.networking import Request
            from yt_dlp.networking.impersonate import ImpersonateTarget
            ydl = ytdlp_util.make_ydl(settings.tiktok_cookies)
            ext = {}
            if ydl._get_available_impersonate_targets():
                ext["impersonate"] = ImpersonateTarget("chrome")
            with ydl.urlopen(Request(url, headers=_HEADERS, extensions=ext)) as resp:
                return resp.read().decode("utf-8", "replace")
        try:
            return await asyncio.to_thread(_get)
        except Exception as exc:  # network / blocked
            raise ProviderError("upstream", str(exc)) from exc

    async def _resolve_photo(self, url: str, kind_id: str) -> Resolved:
        html = await self._fetch_page(url)
        item = parse_item_struct(html)
        if not item:
            raise ProviderError("not_found", "no item data on page")
        items = photo_items(item)
        if not items:
            raise ProviderError("no_media")
        author = (item.get("author") or {}).get("uniqueId") if isinstance(item.get("author"), dict) else item.get("author")
        return Resolved(platform=self.name, media_id=kind_id, source_url=url, title=item.get("desc"),
                        author=author, items=items)

    async def resolve(self, url: str) -> Resolved:
        url = await self._expand(url)
        m = _POST.search(url)
        kind, post_id = m.group(1).lower(), m.group(2)
        canonical = f"https://www.tiktok.com/@_/{'photo' if kind == 'photo' else 'video'}/{post_id}"
        if kind == "photo":
            return await self._resolve_photo(canonical, post_id)
        try:
            res = await ytdlp_util.extract(f"https://www.tiktok.com/@_/video/{post_id}", self.name, settings.tiktok_cookies)
        except ProviderError as exc:
            if exc.code in ("no_media", "unsupported"):
                return await self._resolve_photo(canonical.replace("/video/", "/photo/"), post_id)
            raise
        if all(i.type == "image" for i in res.items):
            # A "video" link that is really a slideshow: yt-dlp only sees the cover.
            return await self._resolve_photo(canonical.replace("/video/", "/photo/"), post_id)
        return res
