"""Provider registry. To add a platform: write a Provider subclass and append it to PROVIDERS."""
from __future__ import annotations

import re

from ..security import allow_hosts
from .base import Provider, ProviderError
from .instagram import InstagramProvider
from .tiktok import TikTokProvider
from .x import XProvider

PROVIDERS: list[Provider] = [TikTokProvider(), InstagramProvider(), XProvider()]

for _p in PROVIDERS:
    allow_hosts(*_p.hosts)

_URL_IN_TEXT = re.compile(r"https?://[^\s<>\"']+", re.I)


def clean_url(text: str) -> str | None:
    """Pull the first link out of whatever was pasted ("Check this out https://…")."""
    if not text:
        return None
    text = text.strip()
    m = _URL_IN_TEXT.search(text)
    if not m and re.match(r"^(www\.)?[\w\-]+\.[a-z]{2,}/", text, re.I):
        m = _URL_IN_TEXT.search("https://" + text)
    if not m:
        return None
    return m.group(0).rstrip(").,;!؟،")


def detect(url: str) -> Provider | None:
    return next((p for p in PROVIDERS if p.matches(url)), None)


__all__ = ["PROVIDERS", "Provider", "ProviderError", "detect", "clean_url"]
