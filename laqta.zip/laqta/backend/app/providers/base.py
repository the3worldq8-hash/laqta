"""Provider plugin contract. Add a platform = add one module + register it."""
from __future__ import annotations

import re
from abc import ABC, abstractmethod

from ..models import Resolved


class ProviderError(Exception):
    """User-facing extraction failure. `code` maps to a translated message in the UI."""

    def __init__(self, code: str, detail: str = "") -> None:
        super().__init__(detail or code)
        self.code = code
        self.detail = detail


class Provider(ABC):
    #: stable id used in API responses and the UI (icons/colors)
    name: str
    #: human label
    label: str
    #: regexes that recognise a link to this platform
    url_patterns: tuple[re.Pattern[str], ...]
    #: host suffixes the server may fetch from for this platform (pages + CDNs)
    hosts: tuple[str, ...]

    def matches(self, url: str) -> bool:
        return any(p.search(url) for p in self.url_patterns)

    @abstractmethod
    async def resolve(self, url: str) -> Resolved:
        """Return metadata and every available rendition. Must not download media."""
