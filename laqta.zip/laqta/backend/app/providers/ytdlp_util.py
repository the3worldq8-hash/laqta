"""Thin adapter around yt-dlp: extraction without download, formats -> Variants."""
from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any

import yt_dlp
from yt_dlp.utils import DownloadError, ExtractorError

from ..config import USER_AGENT, settings
from ..models import MediaItem, Resolved, Variant
from .base import ProviderError

log = logging.getLogger("laqta.ytdlp")


class _QuietLogger:
    def debug(self, msg: str) -> None: ...
    def info(self, msg: str) -> None: ...
    def warning(self, msg: str) -> None: log.debug("yt-dlp warning: %s", msg)
    def error(self, msg: str) -> None: log.debug("yt-dlp error: %s", msg)


def make_ydl(cookies: Path | None = None) -> yt_dlp.YoutubeDL:
    params: dict[str, Any] = {
        "quiet": True,
        "no_warnings": True,
        "noprogress": True,
        "logger": _QuietLogger(),
        "socket_timeout": settings.upstream_timeout,
        "skip_download": True,
        "noplaylist": False,
        "extract_flat": False,
        "http_headers": {"User-Agent": USER_AGENT},
        "cachedir": False,
        "retries": 2,
    }
    if cookies and cookies.is_file():
        params["cookiefile"] = str(cookies)
    return yt_dlp.YoutubeDL(params)


def _classify_error(exc: Exception) -> ProviderError:
    msg = str(exc).lower()
    if any(k in msg for k in ("private", "login", "log in", "registered users", "follow this account", "rate-limit")):
        return ProviderError("private", str(exc))
    if any(k in msg for k in ("not available", "removed", "not found", "404", "does not exist", "unavailable")):
        return ProviderError("not_found", str(exc))
    if "unsupported url" in msg:
        return ProviderError("unsupported", str(exc))
    if "no video" in msg:
        return ProviderError("no_media", str(exc))
    return ProviderError("upstream", str(exc))


def _is_watermarked(f: dict) -> bool:
    note = f"{f.get('format_note') or ''} {f.get('format_id') or ''}".lower()
    return "watermark" in note or f.get("format_id") == "download"


def formats_to_variants(info: dict) -> list[Variant]:
    """Turn processed yt-dlp formats into Variants, pairing video-only with best audio."""
    duration = info.get("duration") or 0
    fmts = [
        f for f in info.get("formats") or []
        if f.get("url") and not _is_watermarked(f)
        and (f.get("protocol") or "https") in ("http", "https", "http_dash_segments")
        and f.get("ext") in ("mp4", "m4a", "mov", "webm")
    ]
    videos = [f for f in fmts if f.get("vcodec") not in (None, "none") or (f.get("height") and f.get("vcodec") is None)]
    audios = [f for f in fmts if f.get("vcodec") == "none" and f.get("acodec") not in (None, "none")]
    audios.sort(key=lambda a: a.get("abr") or a.get("tbr") or 0)

    def size_of(f: dict) -> tuple[int | None, int | None]:
        if f.get("filesize"):
            return int(f["filesize"]), None
        if f.get("filesize_approx"):
            return None, int(f["filesize_approx"])
        if f.get("tbr") and duration:
            return None, int(f["tbr"] * 1000 / 8 * duration)
        return None, None

    out: list[Variant] = []
    for v in videos:
        if v.get("ext") == "webm":
            continue  # Photos app on iOS can't import WebM
        has_audio = v.get("acodec") not in ("none",)
        parts = [v]
        if not has_audio and audios:
            m4a = [a for a in audios if a.get("ext") == "m4a"] or audios
            parts.append(m4a[-1])  # best audio
            has_audio = True
        exact = [size_of(p)[0] for p in parts]
        approx = [size_of(p)[0] or size_of(p)[1] for p in parts]
        tbr = sum((p.get("tbr") or 0) for p in parts) or None
        out.append(Variant(
            kind="ytdlp",
            width=v.get("width"), height=v.get("height"),
            bitrate_kbps=tbr,
            filesize=sum(exact) if all(exact) else None,
            filesize_approx=sum(approx) if all(approx) else None,
            ext="mp4",
            vcodec=v.get("vcodec"),
            has_audio=has_audio,
            formats=parts,
            label=v.get("format_id"),
        ))
    return out


def thumbs_to_image_variants(thumbnails: list[dict], headers: dict[str, str]) -> list[Variant]:
    seen: set[str] = set()
    out = []
    for t in thumbnails or []:
        url = t.get("url")
        if not url or url in seen:
            continue
        seen.add(url)
        ext = "jpg"
        low = url.split("?")[0].lower()
        if low.endswith(".webp"):
            ext = "webp"
        elif low.endswith(".png"):
            ext = "png"
        elif low.endswith(".heic"):
            ext = "heic"
        out.append(Variant(kind="direct", url=url, width=t.get("width"), height=t.get("height"),
                           ext=ext, has_audio=False, headers=dict(headers)))
    return out


def _entry_to_item(ydl: yt_dlp.YoutubeDL, entry: dict) -> MediaItem | None:
    headers = {"User-Agent": USER_AGENT, **(entry.get("http_headers") or {})}
    thumbs = entry.get("thumbnails") or []
    best_thumb = max(thumbs, key=lambda t: (t.get("width") or 0), default=None) if thumbs else None
    thumb_url = entry.get("thumbnail") or (best_thumb or {}).get("url")
    if entry.get("formats"):
        try:
            processed = ydl.process_ie_result(dict(entry), download=False)
        except (DownloadError, ExtractorError):
            processed = None
        variants = formats_to_variants(processed) if processed else []
        if variants:
            return MediaItem(type="video", variants=variants, thumbnail=thumb_url,
                             thumbnail_headers=headers, duration=processed.get("duration"))
    # image post / carousel image: yt-dlp exposes the image candidates as thumbnails
    variants = thumbs_to_image_variants([t for t in thumbs if t.get("width")], headers)
    if variants:
        return MediaItem(type="image", variants=variants, thumbnail=thumb_url or variants[0].url,
                         thumbnail_headers=headers)
    return None


def _extract_sync(url: str, platform: str, cookies: Path | None) -> Resolved:
    ydl = make_ydl(cookies)
    try:
        raw = ydl.extract_info(url, download=False, process=False)
    except (DownloadError, ExtractorError) as exc:
        raise _classify_error(exc) from exc
    if not raw:
        raise ProviderError("no_media")

    entries: list[dict] = []
    if raw.get("_type") == "playlist":
        for e in raw.get("entries") or []:
            if isinstance(e, dict) and e.get("_type") == "url":
                try:
                    e = ydl.extract_info(e["url"], download=False, process=False)
                except (DownloadError, ExtractorError):
                    continue
            if isinstance(e, dict):
                entries.append(e)
    else:
        entries.append(raw)

    items = [it for it in (_entry_to_item(ydl, e) for e in entries) if it]
    if not items:
        raise ProviderError("no_media")
    return Resolved(
        platform=platform,
        media_id=str(raw.get("id") or "media"),
        source_url=raw.get("webpage_url") or url,
        title=raw.get("description") or raw.get("title"),
        author=raw.get("channel") or raw.get("uploader") or raw.get("uploader_id"),
        items=items,
        ydl=ydl,
    )


async def extract(url: str, platform: str, cookies: Path | None = None) -> Resolved:
    return await asyncio.to_thread(_extract_sync, url, platform, cookies)
