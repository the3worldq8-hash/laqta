#!/bin/sh
set -e
# Platforms change often; keep the extractor fresh on every start unless disabled.
if [ "${LAQTA_AUTOUPDATE:-1}" = "1" ]; then
  pip install --user --quiet --upgrade "yt-dlp[default,curl-cffi]" || echo "yt-dlp update skipped"
fi
# One worker: jobs and the metadata cache live in memory. Scale with more containers + sticky sessions.
exec python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 \
  --proxy-headers --forwarded-allow-ips="*" --no-access-log --timeout-keep-alive 30
