export const STRINGS = {
  ar: {
    brand: "لقطة",
    title: "لقطة — احفظ فيديوهات وصور تيك توك وإنستغرام وX",
    heroTitle: "احفظ اللقطة كما نُشرت",
    heroSub: "الصق رابط منشور من TikTok أو Instagram أو X، ونحفظه لك بأعلى جودة متوفرة.",
    inputLabel: "رابط المنشور",
    placeholder: "الصق الرابط هنا",
    paste: "لصق",
    clear: "مسح",
    fetch: "جلب",
    openSource: "المنشور الأصلي",
    quality: "الجودة",
    standard: "عادية",
    standardDesc: "للاستخدام اليومي، حجم أصغر",
    hq: "عالية",
    hqDesc: "أعلى جودة من المصدر، بدون ضغط إضافي",
    download: "تحميل",
    downloadAll: "تحميل الكل ({n})",
    downloadOne: "تحميل",
    saved: "تم",
    saveToPhotos: "حفظ في الصور",
    saveAllToPhotos: "حفظ {n} في الصور",
    iosHint: "اختر «حفظ الفيديو» أو «حفظ الصورة» من القائمة ليُحفظ في ألبوم الصور.",
    promise1: "بدون إعلانات وبدون تسجيل.",
    promise2: "لا نحتفظ بأي محتوى: الملفات تُحذف من الخادم فور وصولها إليك.",
    iosLink: "حفظ بلمسة واحدة على الآيفون",
    legal: "حمّل فقط ما تملك حقه أو ما أذن صاحبه بحفظه.",
    detected: "تم التعرف على {p}",
    resolving: "نقرأ المنشور…",
    pasteDenied: "اسمح بالوصول للحافظة، أو الصق الرابط يدويًا في الخانة.",
    video: "فيديو",
    image: "صورة",
    items: "{n} عناصر",
    phaseQueued: "في الانتظار…",
    phaseFetching: "نجلب الملف من المصدر",
    phaseProcessing: "نجهّز النسخة",
    phaseTransferring: "يُنقل إلى جهازك",
    phaseDone: "اكتمل التحميل",
    sizeUnknown: "الحجم يظهر أثناء التحميل",
    approx: "تقريبًا",
    savedDone: "تم الحفظ",
    downloadedDone: "تم التحميل. تجده في مجلد التنزيلات أو المعرض.",
    noteSourceLow: "أعلى جودة يوفرها المصدر لهذا المنشور هي {res}، ولن نرفعها صناعيًا.",
    noteSingle: "المصدر يوفر جودة واحدة فقط لهذا المنشور، لذلك خيار «عادية» غير متاح.",
    noteTranscoded: "النسخة العادية تُجهَّز على الخادم من الأصل بدقة {res} ومعدل بت أقل.",
    noteResized: "النسخة العادية صورة مصغّرة من الأصل.",
    noteMixed: "الأرقام لكل عنصر تظهر على بطاقته.",
    unavailable: "غير متاح",
    err_invalid_url: "هذا لا يبدو رابطًا. انسخ رابط المنشور من زر المشاركة ثم الصقه هنا.",
    err_unsupported: "الرابط ليس من TikTok أو Instagram أو X.",
    err_not_found: "لم نجد المنشور. ربما حُذف أو أن الرابط ناقص.",
    err_private: "المنشور خاص أو يحتاج تسجيل دخول، ولا يمكن حفظه.",
    err_no_media: "المنشور لا يحتوي على فيديو أو صور.",
    err_upstream: "المنصة لم تستجب الآن. حاول بعد لحظات.",
    err_timeout: "استغرقت المنصة وقتًا طويلًا. حاول مرة أخرى.",
    err_rate_limited: "طلبات كثيرة خلال دقيقة. انتظر قليلًا ثم أعد المحاولة.",
    err_too_large: "الملف أكبر من الحد المسموح.",
    err_expired: "انتهت صلاحية الرابط المؤقت. اضغط «جلب» من جديد.",
    err_unavailable: "هذه الجودة غير متاحة لهذا العنصر.",
    err_processing: "تعذّر تجهيز الملف. جرّب الجودة الأخرى.",
    err_internal: "حدث خطأ في الخادم. أعد المحاولة.",
    err_network: "انقطع الاتصال. تحقق من الإنترنت وأعد المحاولة.",
  },
  en: {
    brand: "Laqta",
    title: "Laqta — Save TikTok, Instagram and X videos and photos",
    heroTitle: "Keep the moment, exactly as posted",
    heroSub: "Paste a TikTok, Instagram or X link and we'll save it in the best quality available.",
    inputLabel: "Post link",
    placeholder: "Paste a link",
    paste: "Paste",
    clear: "Clear",
    fetch: "Fetch",
    openSource: "Original post",
    quality: "Quality",
    standard: "Standard",
    standardDesc: "For everyday use, smaller file",
    hq: "High",
    hqDesc: "Best quality from the source, no extra compression",
    download: "Download",
    downloadAll: "Download all ({n})",
    downloadOne: "Download",
    saved: "Done",
    saveToPhotos: "Save to Photos",
    saveAllToPhotos: "Save {n} to Photos",
    iosHint: "Choose “Save Video” or “Save Image” in the sheet to put it in your Photos library.",
    promise1: "No ads. No sign-up.",
    promise2: "We keep nothing: files are deleted from the server as soon as they reach you.",
    iosLink: "One-tap saving on iPhone",
    legal: "Only download content you own or have permission to save.",
    detected: "{p} link detected",
    resolving: "Reading the post…",
    pasteDenied: "Allow clipboard access, or paste the link into the field yourself.",
    video: "Video",
    image: "Photo",
    items: "{n} items",
    phaseQueued: "Waiting…",
    phaseFetching: "Fetching from the source",
    phaseProcessing: "Preparing your copy",
    phaseTransferring: "Sending to your device",
    phaseDone: "Download complete",
    sizeUnknown: "Size appears while downloading",
    approx: "approx.",
    savedDone: "Saved",
    downloadedDone: "Downloaded. Find it in Downloads or your gallery.",
    noteSourceLow: "The best this post offers is {res}. We won't upscale it artificially.",
    noteSingle: "The source offers only one quality for this post, so Standard isn't available.",
    noteTranscoded: "Standard is encoded on our server from the original at {res} with a lower bitrate.",
    noteResized: "Standard is a downscaled copy of the original photo.",
    noteMixed: "Per-item details are shown on each card.",
    unavailable: "Unavailable",
    err_invalid_url: "That doesn't look like a link. Copy it from the post's Share button and paste it here.",
    err_unsupported: "This link isn't from TikTok, Instagram or X.",
    err_not_found: "We couldn't find that post. It may be deleted or the link is incomplete.",
    err_private: "This post is private or needs a login, so it can't be saved.",
    err_no_media: "This post has no video or photos.",
    err_upstream: "The platform didn't respond. Try again in a moment.",
    err_timeout: "The platform took too long. Try again.",
    err_rate_limited: "Too many requests in a minute. Wait a little, then retry.",
    err_too_large: "The file is larger than the allowed limit.",
    err_expired: "This session expired. Tap Fetch again.",
    err_unavailable: "That quality isn't available for this item.",
    err_processing: "We couldn't prepare the file. Try the other quality.",
    err_internal: "Server error. Please retry.",
    err_network: "Connection lost. Check your internet and retry.",
  },
};

let lang = "ar";

export function initLang() {
  let saved = null;
  try { saved = localStorage.getItem("laqta.lang"); } catch { /* storage unavailable */ }
  lang = saved || ((navigator.language || "ar").toLowerCase().startsWith("ar") ? "ar" : "en");
  apply();
  return lang;
}

export function getLang() { return lang; }

export function setLang(next) {
  lang = next;
  try { localStorage.setItem("laqta.lang", next); } catch { /* ignore */ }
  apply();
}

export function t(key, vars = {}) {
  const s = STRINGS[lang][key] ?? STRINGS.en[key] ?? key;
  return s.replace(/\{(\w+)\}/g, (_, k) => (vars[k] ?? ""));
}

function apply() {
  const root = document.documentElement;
  root.lang = lang;
  root.dir = lang === "ar" ? "rtl" : "ltr";
  document.title = t("title");
  document.querySelectorAll("[data-i18n]").forEach((el) => { el.textContent = t(el.dataset.i18n); });
  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => { el.placeholder = t(el.dataset.i18nPlaceholder); });
  document.querySelectorAll("[data-i18n-aria]").forEach((el) => { el.setAttribute("aria-label", t(el.dataset.i18nAria)); });
  const btn = document.getElementById("langBtn");
  if (btn) { btn.textContent = lang === "ar" ? "EN" : "ع"; btn.setAttribute("aria-label", lang === "ar" ? "English" : "العربية"); }
}

const nf = () => new Intl.NumberFormat(lang === "ar" ? "ar-u-nu-latn" : "en", { maximumFractionDigits: 1 });

export function fmtBytes(n) {
  if (!n && n !== 0) return "";
  const units = ["B", "KB", "MB", "GB"]; // Latin units read cleanly inside LTR spec lines in both languages
  let i = 0; let v = n;
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
  const digits = i >= 2 ? (v >= 100 ? 0 : 1) : 0;
  return `${new Intl.NumberFormat("en", { maximumFractionDigits: digits, minimumFractionDigits: digits }).format(v)} ${units[i]}`;
}

export function fmtBitrate(kbps) {
  if (!kbps) return "";
  return kbps >= 1000 ? `${(kbps / 1000).toFixed(1)} Mbps` : `${Math.round(kbps)} kbps`;
}

export function fmtDuration(s) {
  if (!s) return "";
  s = Math.round(s);
  const m = Math.floor(s / 60); const r = String(s % 60).padStart(2, "0");
  return `${m}:${r}`;
}

export function fmtNumber(n) { return nf().format(n); }
