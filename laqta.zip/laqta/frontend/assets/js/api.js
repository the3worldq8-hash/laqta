export class ApiError extends Error {
  constructor(code, status = 0) { super(code); this.code = code; this.status = status; }
}

async function json(res) {
  let body = null;
  try { body = await res.json(); } catch { /* not json */ }
  if (!res.ok) throw new ApiError(body?.code || (res.status === 429 ? "rate_limited" : "internal"), res.status);
  return body;
}

async function call(path, opts = {}) {
  let res;
  try {
    res = await fetch(path, { headers: { "Content-Type": "application/json" }, ...opts });
  } catch (e) {
    if (e.name === "AbortError") throw e;
    throw new ApiError("network");
  }
  return json(res);
}

export const resolve = (url, signal) => call("/api/resolve", { method: "POST", body: JSON.stringify({ url }), signal });
export const createJob = (token, signal) => call("/api/jobs", { method: "POST", body: JSON.stringify({ token }), signal });
export const jobStatus = (id, signal) => call(`/api/jobs/${encodeURIComponent(id)}`, { signal });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/**
 * Runs one download end-to-end and returns a File.
 * onUpdate({phase, progress, received, total, speed})
 */
export async function downloadOption(option, onUpdate, signal) {
  let job = await createJob(option.token, signal);
  let wait = 250;
  while (job.state === "queued" || job.state === "running") {
    onUpdate({ phase: job.phase === "queued" ? "queued" : job.phase, progress: job.progress });
    await sleep(wait);
    wait = Math.min(900, wait + 100);
    job = await jobStatus(job.id, signal);
  }
  if (job.state === "error") throw new ApiError(job.error || "internal");

  let res;
  try {
    res = await fetch(`/api/jobs/${encodeURIComponent(job.id)}/file`, { signal });
  } catch (e) {
    if (e.name === "AbortError") throw e;
    throw new ApiError("network");
  }
  if (!res.ok) await json(res);

  const total = Number(res.headers.get("Content-Length")) || job.size || (option.size_exact ? option.size : 0) || 0;
  const type = res.headers.get("Content-Type") || job.mime;
  const name = res.headers.get("X-Laqta-Filename") || job.filename;
  const chunks = [];
  let received = 0;
  const t0 = performance.now();
  onUpdate({ phase: "transferring", progress: 0, received, total, speed: 0 });

  if (res.body && res.body.getReader) {
    const reader = res.body.getReader();
    for (;;) {
      let step;
      try { step = await reader.read(); } catch (e) {
        if (e.name === "AbortError") throw e;
        throw new ApiError("network");
      }
      if (step.done) break;
      chunks.push(step.value);
      received += step.value.byteLength;
      const secs = (performance.now() - t0) / 1000;
      onUpdate({ phase: "transferring", progress: total ? received / total : null, received, total, speed: secs > 0.3 ? received / secs : 0 });
    }
  } else {
    const buf = await res.arrayBuffer();
    chunks.push(new Uint8Array(buf));
    received = buf.byteLength;
  }
  if (total && received < total * 0.98) throw new ApiError("network");
  onUpdate({ phase: "done", progress: 1, received, total: received, speed: 0 });
  return new File(chunks, name, { type });
}
