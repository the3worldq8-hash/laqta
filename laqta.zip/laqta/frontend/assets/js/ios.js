// Fill the real server address into the Shortcut instructions.
document.querySelectorAll("[data-origin]").forEach((el) => {
  el.textContent = el.textContent.replace("{origin}", location.origin);
});
document.getElementById("langBtn")?.addEventListener("click", () => {
  const ar = document.documentElement.lang === "ar";
  document.documentElement.lang = ar ? "en" : "ar";
  document.documentElement.dir = ar ? "ltr" : "rtl";
  document.querySelectorAll("[data-lang]").forEach((s) => { s.hidden = s.dataset.lang !== document.documentElement.lang; });
  document.getElementById("langBtn").textContent = ar ? "ع" : "EN";
  try { localStorage.setItem("laqta.lang", document.documentElement.lang); } catch { /* ignore */ }
});
let pref = null;
try { pref = localStorage.getItem("laqta.lang"); } catch { /* ignore */ }
if (pref === "en") document.getElementById("langBtn")?.click();
