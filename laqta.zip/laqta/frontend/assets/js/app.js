import { initLang, setLang, getLang, t, fmtBytes, fmtBitrate, fmtDuration } from "./i18n.js";
import { resolve, downloadOption, ApiError } from "./api.js";
import { save, isIOS, canShareFiles } from "./saver.js";

const $ = (id) => document.getElementById(id);
const els = {
  lens: $("lens"), input: $("urlInput"), paste: $("pasteBtn"), clear: $("clearBtn"), go: $("goBtn"),
  chip: $("platformChip"), status: $("status"), result: $("result"), gallery: $("gallery"),
  resPlatform: $("resPlatform"), resAuthor: $("resAuthor"), resSource: $("resSource"), resCaption: $("resCaption"),
  qNote: $("qNote"), dl: $("downloadBtn"), dlLabel: $("downloadLabel"), dlMeta: $("downloadMeta"),
  progress: $("progress"), barFill: $("barFill"), pText: $("progressText"), pBytes: $("progressBytes"),
  savePanel: $("savePanel"), saveBtn: $("saveBtn"), saveLabel: $("saveLabel"), saveHint: $("saveHint"),
  tpl: $("tileTpl"),
};

// Mirrors backend provider patterns, only for instant feedback; the server is authoritative.
const PLATFORMS = [
  { id: "tiktok", label: "TikTok", re: /(^|\.)tiktok\.com\//i },
  { id: "instagram", label: "Instagram", re: /(^|\.)(instagram\.com|instagr\.am)\//i },
  { id: "x", label: "X", re: /(^|\.)(x|twitter|fxtwitter|vxtwitter|fixupx)\.com\/.+\/status|(^|\/\/)t\.co\//i },
];

const state = { data: null, q: "hq", busy: false, ctrl: null, pendingFiles: null, lastUrl: "" };

function extractUrl(text) {
  const m = (text || "").match(/https?:\/\/[^\s<>"']+/i);
  if (m) return m[0].replace(/[).,;!؟،]+$/, "");
  const bare = (text || "").trim();
  return /^(www\.)?[\w-]+\.[a-z]{2,}\//i.test(bare) ? `https://${bare}` : "";
}

function detect(url) {
  if (!url) return null;
  let host = "";
  try { const u = new URL(url); host = u.hostname + u.pathname; } catch { return null; }
  return PLATFORMS.find((p) => p.re.test(host) || p.re.test(url)) || null;
}

function setStatus(msg, isError = false) {
  els.status.textContent = msg || "";
  els.status.classList.toggle("error", !!isError);
}

function showDetected() {
  const url = extractUrl(els.input.value);
  const p = detect(url);
  els.clear.hidden = !els.input.value;
  document.querySelectorAll(".platforms li").forEach((li) => li.classList.toggle("on", !!p && li.dataset.p === p.id));
  if (p) {
    els.lens.dataset.platform = p.id;
    els.chip.textContent = p.label;
    els.chip.hidden = false;
  } else {
    delete els.lens.dataset.platform;
    els.chip.hidden = true;
  }
  return { url, p };
}

function errorText(e) {
  const code = e instanceof ApiError ? e.code : "internal";
  return t(`err_${code}`) || t("err_internal");
}

// ------------------------------------------------------------------ resolve
async function run() {
  const { url, p } = showDetected();
  if (!url) { setStatus(t("err_invalid_url"), true); return; }
  if (!p) { setStatus(t("err_unsupported"), true); return; }
  if (state.busy) state.ctrl?.abort();
  state.ctrl = new AbortController();
  state.busy = true;
  state.lastUrl = url;
  els.lens.classList.add("busy");
  els.go.disabled = true;
  setStatus(t("resolving"));
  try {
    const data = await resolve(url, state.ctrl.signal);
    state.data = data;
    setStatus("");
    render();
  } catch (e) {
    if (e.name === "AbortError") return;
    setStatus(errorText(e), true);
  } finally {
    state.busy = false;
    els.lens.classList.remove("busy");
    els.go.disabled = false;
  }
}

// ------------------------------------------------------------------ render
function optFor(item, q) { return item.options[q] || item.options.hq; }

function specLine(opt, item) {
  if (!opt) return `<span>${t("unavailable")}</span>`;
  const dims = item.type === "video" ? (opt.resolution || "") : (opt.width && opt.height ? `${opt.width}×${opt.height}` : "");
  const size = opt.size ? `${opt.size_exact ? "" : "~"}${fmtBytes(opt.size)}` : "";
  const br = item.type === "video" ? fmtBitrate(opt.bitrate_kbps) : "";
  return [dims, size].filter(Boolean).join("  ") + (br ? `<small>${br}</small>` : "");
}

function totals(q) {
  let size = 0; let exact = true; let known = true;
  for (const it of state.data.items) {
    const o = optFor(it, q);
    if (!o?.size) { known = false; continue; }
    size += o.size; exact = exact && o.size_exact;
  }
  return { size: known ? size : (size || null), exact: known && exact };
}

function render() {
  const d = state.data;
  els.result.hidden = false;
  els.result.dataset.platform = d.platform;
  els.resPlatform.textContent = PLATFORMS.find((p) => p.id === d.platform)?.label || d.platform;
  els.resAuthor.textContent = d.author ? `@${d.author.replace(/^@/, "")}` : "";
  els.resSource.href = d.source_url;
  els.resCaption.textContent = d.title || "";
  hideProgress();
  els.savePanel.hidden = true;
  state.pendingFiles = null;

  // gallery
  els.gallery.replaceChildren();
  const multi = d.items.length > 1;
  els.gallery.classList.toggle("multi", multi);
  d.items.forEach((item, i) => {
    const node = els.tpl.content.firstElementChild.cloneNode(true);
    const img = node.querySelector("img");
    const media = node.querySelector(".tile-media");
    const hq = item.options.hq;
    if (hq?.width && hq?.height) media.style.setProperty("--ar", `${hq.width} / ${hq.height}`);
    if (item.thumb) {
      img.addEventListener("load", () => { img.classList.add("loaded"); media.classList.add("ready"); }, { once: true });
      img.addEventListener("error", () => media.classList.add("ready"), { once: true });
      img.src = item.thumb;
    } else media.classList.add("ready");
    img.alt = item.type === "video" ? t("video") : t("image");
    const cap = node.querySelector(".tile-cap");
    cap.textContent = item.type === "video" ? `${t("video")} ${fmtDuration(item.duration)}`.trim()
      : (multi ? `${i + 1}/${d.items.length}` : t("image"));
    const btn = node.querySelector(".tile-dl");
    btn.textContent = t("downloadOne");
    btn.addEventListener("click", () => downloadItems([i], btn));
    els.gallery.appendChild(node);
  });

  // quality
  const anyStd = d.items.some((it) => it.options.standard);
  const stdInput = document.querySelector('input[name="q"][value="standard"]');
  stdInput.disabled = !anyStd;
  if (!anyStd) state.q = "hq";
  document.querySelector(`input[name="q"][value="${state.q}"]`).checked = true;
  updateQuality();
}

function updateQuality() {
  const d = state.data;
  if (!d) return;
  const multi = d.items.length > 1;
  for (const q of ["standard", "hq"]) {
    const el = document.querySelector(`[data-spec="${q}"]`);
    if (!multi) {
      el.innerHTML = specLine(d.items[0].options[q], d.items[0]);
    } else {
      const avail = d.items.some((it) => it.options[q]);
      const tot = totals(q);
      el.innerHTML = avail
        ? `${t("items", { n: d.items.length })}${tot.size ? `  ${tot.exact ? "" : "~"}${fmtBytes(tot.size)}` : ""}`
        : `<span>${t("unavailable")}</span>`;
    }
  }
  // explanation of what the chosen option really is
  const notes = new Set();
  const first = d.items[0];
  const chosen = optFor(first, state.q);
  const hqNotes = first.options.hq?.notes || [];
  if (hqNotes.includes("single_quality")) notes.add(t("noteSingle"));
  if (hqNotes.includes("source_low")) notes.add(t("noteSourceLow", { res: first.options.hq.resolution || `${first.options.hq.width}×${first.options.hq.height}` }));
  if (state.q === "standard" && chosen?.notes?.includes("transcoded")) notes.add(t("noteTranscoded", { res: chosen.resolution }));
  if (state.q === "standard" && chosen?.notes?.includes("resized")) notes.add(t("noteResized"));
  els.qNote.textContent = [...notes].join(" ");

  const tot = multi ? totals(state.q) : (() => { const o = optFor(first, state.q); return { size: o?.size, exact: o?.size_exact }; })();
  els.dlLabel.textContent = multi ? t("downloadAll", { n: d.items.length }) : t("download");
  els.dlMeta.textContent = tot.size ? `${tot.exact ? "" : "~"}${fmtBytes(tot.size)}` : "";
}

// ------------------------------------------------------------------ progress
function hideProgress() { els.progress.hidden = true; els.progress.classList.remove("indeterminate"); }

function showProgress({ phase, progress, received, total, speed }, label = "") {
  els.progress.hidden = false;
  const name = { queued: "phaseQueued", fetching: "phaseFetching", processing: "phaseProcessing", transferring: "phaseTransferring", done: "phaseDone" }[phase] || "phaseQueued";
  const indeterminate = progress == null || (phase !== "done" && progress === 0 && phase !== "transferring");
  els.progress.classList.toggle("indeterminate", indeterminate);
  if (!indeterminate) els.barFill.style.setProperty("--p", String(Math.max(0, Math.min(1, progress))));
  const pct = progress != null && !indeterminate ? ` ${Math.round(progress * 100)}%` : "";
  els.pText.textContent = `${label}${t(name)}${pct}`;
  if (phase === "transferring" || phase === "done") {
    const sp = speed ? `  ${fmtBytes(speed)}/s` : "";
    els.pBytes.textContent = total ? `${fmtBytes(received)} / ${fmtBytes(total)}${sp}` : `${fmtBytes(received)}${sp}`;
  } else {
    els.pBytes.textContent = "";
  }
}

// ------------------------------------------------------------------ download & save
async function downloadItems(indices, tileBtn = null) {
  if (state.dlBusy) return;
  state.dlBusy = true;
  els.dl.disabled = true;
  els.savePanel.hidden = true;
  const d = state.data;
  const files = [];
  try {
    for (let k = 0; k < indices.length; k++) {
      const item = d.items[indices[k]];
      const opt = optFor(item, state.q);
      const label = indices.length > 1 ? `${k + 1}/${indices.length}  ` : "";
      const file = await downloadOption(opt, (u) => showProgress(u, label));
      files.push(file);
    }
    await deliver(files);
    if (tileBtn) { tileBtn.textContent = t("saved"); tileBtn.classList.add("done"); }
  } catch (e) {
    hideProgress();
    setStatus(errorText(e), true);
  } finally {
    state.dlBusy = false;
    els.dl.disabled = false;
  }
}

async function deliver(files) {
  const shareable = isIOS && canShareFiles(files);
  if (!shareable) {
    await save(files, { preferShare: false });
    setStatus(t("downloadedDone"));
    return;
  }
  // iOS: try the share sheet right away; if the tap "expired" during the download, ask for one more tap.
  const r = await save(files, { preferShare: true });
  if (r === "shared") { setStatus(t("savedDone")); return; }
  state.pendingFiles = files;
  els.saveLabel.textContent = files.length > 1 ? t("saveAllToPhotos", { n: files.length }) : t("saveToPhotos");
  els.saveHint.textContent = t("iosHint");
  els.savePanel.hidden = false;
  els.saveBtn.focus({ preventScroll: true });
  els.savePanel.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

// ------------------------------------------------------------------ events
els.lens.addEventListener("submit", (e) => { e.preventDefault(); els.input.blur(); run(); });

els.input.addEventListener("input", () => {
  const { url, p } = showDetected();
  setStatus(p ? t("detected", { p: p.label }) : "");
  if (p && url !== state.lastUrl && /\/(video|photo|p|reels?|tv|status)\/[\w-]{5,}|vm\.tiktok|vt\.tiktok|\/t\/|t\.co\/|\/share\//i.test(url)) {
    clearTimeout(state.typeTimer);
    state.typeTimer = setTimeout(run, 450);
  }
});

els.input.addEventListener("paste", () => setTimeout(() => {
  const { url, p } = showDetected();
  if (url) { els.input.value = url; showDetected(); }
  if (p) run();
}, 0));

els.paste.addEventListener("click", async () => {
  try {
    const text = await navigator.clipboard.readText();
    const url = extractUrl(text);
    if (!url) { setStatus(t("err_invalid_url"), true); return; }
    els.input.value = url;
    showDetected();
    run();
  } catch {
    els.input.focus();
    setStatus(t("pasteDenied"));
  }
});

els.clear.addEventListener("click", () => {
  els.input.value = "";
  state.lastUrl = "";
  showDetected();
  setStatus("");
  els.input.focus();
});

document.querySelectorAll('input[name="q"]').forEach((r) => r.addEventListener("change", () => {
  state.q = r.value;
  els.savePanel.hidden = true;
  document.querySelectorAll(".tile-dl.done").forEach((b) => { b.classList.remove("done"); b.textContent = t("downloadOne"); });
  updateQuality();
}));

els.dl.addEventListener("click", () => downloadItems(state.data.items.map((_, i) => i)));

els.saveBtn.addEventListener("click", async () => {
  if (!state.pendingFiles) return;
  const r = await save(state.pendingFiles, { preferShare: true });
  if (r === "shared") { setStatus(t("savedDone")); els.savePanel.hidden = true; state.pendingFiles = null; }
});

$("langBtn").addEventListener("click", () => {
  setLang(getLang() === "ar" ? "en" : "ar");
  showDetected();
  if (state.data) updateQuality();
  els.gallery.querySelectorAll(".tile-dl:not(.done)").forEach((b) => { b.textContent = t("downloadOne"); });
});

// Share-target / deep link support: /?url=...
initLang();
const qs = new URLSearchParams(location.search);
const incoming = qs.get("url") || qs.get("text");
if (incoming) {
  els.input.value = extractUrl(incoming) || incoming;
  history.replaceState(null, "", "/");
  showDetected();
  run();
}
