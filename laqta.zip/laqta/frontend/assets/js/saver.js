/**
 * Getting a file into the user's library.
 *
 * iPhone/iPad: Safari can't write to Photos directly; the only browser route is the system
 * share sheet (Web Share API with files), whose "Save Video"/"Save Image" action saves straight
 * into Photos — never into Files. Safari only allows share() during a user tap, so after a long
 * download we may need one more tap ("Save to Photos"), which the UI provides.
 * Android/desktop: a normal download (Android galleries index the Downloads folder).
 */
const ua = navigator.userAgent;
export const isIOS = /iP(hone|od|ad)/.test(ua) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
export const isAndroid = /Android/i.test(ua);

export function canShareFiles(files) {
  try { return !!(navigator.canShare && navigator.share && navigator.canShare({ files })); } catch { return false; }
}

/** Prefer the share sheet on iOS. Returns "shared" | "cancelled" | "needs-tap" | "downloaded". */
export async function save(files, { preferShare = isIOS } = {}) {
  if (preferShare && canShareFiles(files)) {
    try {
      await navigator.share({ files });
      return "shared";
    } catch (e) {
      if (e && e.name === "AbortError") return "cancelled";
      if (e && e.name === "NotAllowedError") return "needs-tap";
      // fall through to a plain download for anything else
    }
  }
  for (const f of files) {
    const url = URL.createObjectURL(f);
    const a = document.createElement("a");
    a.href = url;
    a.download = f.name;
    a.rel = "noopener";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60_000);
    if (files.length > 1) await new Promise((r) => setTimeout(r, 350)); // browsers throttle bursts
  }
  return "downloaded";
}
