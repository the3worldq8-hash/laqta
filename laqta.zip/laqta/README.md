# لقطة — Laqta

موقع لحفظ فيديوهات وصور **TikTok** و**Instagram** و**X** بجودتها الحقيقية، مع حفظ مباشر في ألبوم الصور على الآيفون. بدون إعلانات، بدون حساب، وبدون الاحتفاظ بأي محتوى.

> A self-hosted downloader for TikTok, Instagram and X (videos, photos, carousels) with honest Standard/HQ options and direct save-to-Photos on iPhone. English summary at the bottom.

---

## المزايا

| الميزة | كيف نُفذت |
|---|---|
| التعرف التلقائي على المنصة | فور اللصق في الواجهة، والخادم يتحقق ثانيةً (`providers/`) |
| زر لصق | Clipboard API، وإن رُفض الإذن يُركّز الحقل مع تنبيه |
| معاينة قبل التحميل | صورة الغلاف (عبر وكيل موقّع)، الكاتب، النص، المدة، عدد العناصر |
| منشورات متعددة الصور | كل عنصر في بطاقة مع زر تحميل خاص، و«تحميل الكل» |
| نسبة التقدم والحجم | مرحلتان حقيقيتان: تجهيز على الخادم (نسبة من yt-dlp/ffmpeg) ثم النقل لجهازك (بايتات/سرعة) |
| الحجم والدقة قبل التحميل | الحجم الدقيق عبر طلب HEAD للـCDN، أو تقدير موسوم بـ`~` عند التحويل |
| عدم الاحتفاظ بالمحتوى | لا قاعدة بيانات؛ الملفات المؤقتة تُحذف فور التسليم، ومنظّف كل دقيقة، و`/tmp` في الذاكرة داخل Docker، وسجلات الوصول معطّلة |
| عربي/إنجليزي | RTL/LTR كامل، يُحفظ اختيار اللغة |
| الأمان | توكنات HMAC، قائمة مسموحة لنطاقات CDN (حماية SSRF)، حد طلبات لكل IP، CSP صارمة بدون سكربتات inline، حد لحجم الملف والمدة |

## الجودتان: فرق حقيقي وليس اسم زر

`backend/app/quality.py` يطبق هذه القواعد:

- **عالية (HQ)**: أعلى نسخة يقدمها المصدر فعليًا (أعلى دقة ثم أعلى معدل بت). لا تُعاد ترميزها أبدًا ولا تُرفع دقتها. فقط دمج بلا فقد (فيديو+صوت منفصلين في إنستغرام)، أو إعادة وسم HEVC إلى `hvc1` لأن تطبيق الصور في الآيفون يرفض وسم `hev1` الذي يستخدمه تيك توك.
- **عادية (Standard)**:
  1. إن وفّر المصدر نسخة أصغر فعلًا (≤720p، وحجمها ≤80% من الأعلى) تُستخدم كما هي، مثل X: ‏320/720/1080، وتيك توك: h264 720p مقابل HEVC 1080p.
  2. وإلا وكان الأصل أعلى من 720p: ترميز حقيقي على الخادم بـH.264، الضلع الأقصر 720، ومعدل بت محدود (1.8Mbps للفيديو، وAAC بـ96k للصوت).
  3. وإلا (الأصل 720p أو أقل بنسخة واحدة): **لا نعرض خيار «عادية»** ونوضح للمستخدم أن المصدر يوفر جودة واحدة.
- الصور: الأصل للعالية، ونسخة أصغر من المنصة إن وُجدت (X: ‏`orig` مقابل `large`، إنستغرام: 1080 مقابل 750)، أو تصغير إلى 1600px. صور WebP تُحوّل إلى JPEG حتى يقبلها ألبوم الصور.
- إن كانت أعلى جودة متاحة أقل من 720p، تظهر للمستخدم رسالة توضح ذلك.

## الحفظ في ألبوم الصور على الآيفون

سفاري لا يسمح لأي موقع بالكتابة في تطبيق الصور مباشرة، فوفرنا ثلاث طرق، وكلها تحفظ في **الصور** وليس **الملفات**:

1. **من الموقع**: بعد التحميل تُفتح قائمة المشاركة بالملف/الملفات (Web Share API مع الملفات)، و«حفظ الفيديو» أو «حفظ X عناصر» تحفظ مباشرة في الصور. إذا طال التحميل وانتهت مهلة «لمسة المستخدم» في سفاري، يظهر زر «حفظ في الصور» لإكمالها بلمسة واحدة.
2. **اختصار iOS** (لمسة واحدة من داخل تطبيق المنصة، بدون App Store): نقطة النهاية `GET /api/shortcut?url=…&q=hq` تُرجع رابط ملف لكل عنصر، والاختصار يحفظها بـ«حفظ في ألبوم الصور». الخطوات في صفحة `/ios.html` بعنوان خادمك الفعلي.
3. **تطبيق iOS أصلي** في `ios/` (SwiftUI + امتداد مشاركة «حفظ بلقطة»): يطلب صلاحية `PHAccessLevel.addOnly` فقط (إضافة دون قراءة المكتبة) ويحفظ عبر `PHAssetCreationRequest`. يُبنى بـ:
   ```bash
   cd ios && brew install xcodegen && xcodegen   # ثم افتح Laqta.xcodeproj
   ```
   عدّل `LAQTA_SERVER` و`bundleIdPrefix` و`DEVELOPMENT_TEAM` في `project.yml`.

على أندرويد والكمبيوتر يتم تنزيل عادي (المعرض في أندرويد يقرأ مجلد التنزيلات). والموقع PWA: على أندرويد يمكن تثبيته ثم المشاركة إليه مباشرة (`share_target`).

## البنية

```
backend/app/
  main.py            API + الواجهة الثابتة + ترويسات الأمان
  providers/         إضافة لكل منصة (المعيار في base.py)
    tiktok.py        فيديو عبر yt-dlp (بدون العلامة المائية) + عروض الصور من بيانات الصفحة
    instagram.py     منشورات/ريلز/كاروسيل (فيديو + صور) عبر yt-dlp
    x.py             واجهة التضمين العامة (syndication) مع بديل yt-dlp
    ytdlp_util.py    تحويل صيغ yt-dlp إلى Variants موحّدة
  quality.py         بناء خياري «عادية/عالية» بصدق
  jobs.py            مهام التحميل والتقدم ودورة حياة الملفات المؤقتة
  media.py           ffmpeg (دمج/إعادة وسم/ترميز) وPillow
  security.py        توكنات موقّعة، حد الطلبات، قائمة النطاقات
frontend/            HTML/CSS/JS بدون أدوات بناء، الخطوط مستضافة ذاتيًا
ios/                 تطبيق SwiftUI + Share Extension
```

مسار الطلب: `POST /api/resolve` (بيانات فقط، لا يُنزّل أي وسائط) ← `POST /api/jobs` ← `GET /api/jobs/{id}` (التقدم) ← `GET /api/jobs/{id}/file`.
الملفات التي لا تحتاج معالجة تُمرَّر مباشرة من الـCDN إلى المستخدم (stream) دون أن تُكتب على قرص الخادم.

### إضافة منصة جديدة

1. أنشئ `providers/<name>.py` بصنف يرث `Provider`، وحدد `url_patterns` و`hosts` (نطاقات الصفحات والـCDN) ودالة `resolve()` تُرجع `Resolved` بعناصر `MediaItem` ونسخ `Variant`. إن كان yt-dlp يدعم المنصة يكفي سطر واحد: `return await ytdlp_util.extract(url, self.name)`.
2. أضفه إلى `PROVIDERS` في `providers/__init__.py`.
3. أضف نمط الرابط واللون في `frontend/assets/js/app.js` و`styles.css`.

الجودة والتقدم والحفظ والأمان تعمل تلقائيًا للمنصة الجديدة.

## التشغيل

محليًا:
```bash
cd backend
pip install -r requirements-dev.txt      # يحتاج ffmpeg مثبتًا
LAQTA_SECRET=dev python -m uvicorn app.main:app --reload --no-access-log
# http://127.0.0.1:8000
```

النشر (Docker + Caddy مع شهادة HTTPS تلقائية):
```bash
cp .env.example .env        # عدّل LAQTA_DOMAIN و LAQTA_SECRET
docker compose up -d --build
```
- **HTTPS إلزامي**: زر اللصق وقائمة المشاركة في الآيفون لا يعملان بدونه.
- الحاوية تحدّث yt-dlp عند كل تشغيل (`LAQTA_AUTOUPDATE=1`) لأن المنصات تغيّر واجهاتها باستمرار. أعد التشغيل أسبوعيًا، أو عند ظهور أخطاء «المنصة لم تستجب».
- عامل واحد لكل حاوية (المهام في الذاكرة). للتوسع: عدة حاويات مع جلسات لاصقة (sticky sessions) أو نقل `JobManager` إلى Redis.
- يُفضّل خادم بعنوان IP لا يحظره إنستغرام، فإنستغرام يحد الطلبات المجهولة. وعند الحاجة يمكن تمرير ملف cookies لحساب مخصص عبر `LAQTA_IG_COOKIES`.

## الاختبارات

```bash
cd backend && pytest -q
```
31 اختبارًا تمر جميعها: التعرف على الروابط (15 صيغة)، خوارزمية توكن X مطابقة لـJavaScript، تحليل بيانات X وصور تيك توك، قواعد الجودة، ثم سيناريوهات كاملة عبر الـAPI على وسائط حقيقية مولّدة بـffmpeg: تمرير مباشر بحجم مطابق للمعروض، ترميز 720p حقيقي (التحقق بـffprobe من الدقة والترميز ومعدل البت)، دمج DASH، إعادة وسم HEVC إلى `hvc1`، تصغير الصور وتحويل WebP، استبعاد نسخة العلامة المائية، التحقق من عدم بقاء ملفات بعد التسليم، والأخطاء والتوكنات المزوّرة.

`python -m tests.demo_server` يشغّل الموقع كاملًا على وسائط محلية للتجربة (روابط مثل `https://x.com/demo_carousel/status/123456`).

## حدود يجب معرفتها

- المنصات تغيّر واجهاتها دون إشعار، فحدّث yt-dlp دوريًا. المحتوى الخاص، والقصص، والمنشورات التي تتطلب تسجيل الدخول لا تُدعم بدون cookies.
- المعاينة صورة غلاف وليست تشغيلًا للفيديو، حتى لا يُنزَّل الفيديو مرتين.
- على الآيفون من سفاري تبقى قائمة المشاركة خطوة إلزامية من النظام؛ الحفظ بلا أي قائمة متاح فقط عبر الاختصار أو التطبيق.
- مسؤولية حقوق المحتوى على المستخدم؛ تذكير بذلك في تذييل الموقع. راجع شروط المنصات والقوانين المحلية قبل النشر العام.

---

## English summary

FastAPI + yt-dlp + ffmpeg backend with a provider plugin per platform; dependency-free bilingual (AR/EN, RTL) PWA frontend.
**HQ** is always the best rendition the source actually serves (never upscaled or re-encoded; losslessly merged/retagged only when needed). **Standard** is a real smaller rendition from the source, or a real server-side H.264 720p encode with a capped bitrate. When neither is meaningful it is hidden and the user is told why. Exact sizes come from CDN HEAD requests; estimates are marked `~`.
iPhone saving goes to **Photos**, not Files: via the Web Share sheet on the website, an iOS Shortcut (`/api/shortcut`) for one tap from the platform's own share sheet, or the included SwiftUI app + Share Extension that use add-only Photos access.
Deploy with `docker compose up -d --build` behind Caddy (HTTPS required). Run `pytest -q` in `backend/` to run the tests.
